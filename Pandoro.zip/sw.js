/* Offline support. Network first (so updates always show up), falling back to the last copy we saw.
   Everything the app has loaded once keeps working without a connection. */
const CACHE = 'pandoro-v1';
const CORE = ['./', 'index.html', 'css/style.css', 'manifest.webmanifest', 'icons/icon-192.png',
  'js/assets.js', 'js/sprites.js', 'js/art.js', 'js/doodles.js', 'js/store.js', 'js/audio.js', 'js/panda.js',
  'js/timer.js', 'js/rewards.js', 'js/stats.js', 'js/panels.js', 'js/coach.js', 'js/app.js'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(CORE)).catch(() => {}));
  self.skipWaiting();
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  const same = url.origin === self.location.origin, fonts = /fonts\.(googleapis|gstatic)\.com$/.test(url.hostname);
  if (!same && !fonts) return;
  e.respondWith(fetch(req).then((res) => {
    if (res && (res.ok || res.type === 'opaque')) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); }
    return res;
  }).catch(() => caches.match(req, { ignoreSearch: same }).then((r) => r || (req.mode === 'navigate' ? caches.match('index.html') : undefined))));
});
