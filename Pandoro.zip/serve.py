"""Tiny local server for Pandoro that disables caching, so edits show up on refresh.
Usage: python serve.py [port]   (default 5190)"""
import http.server, os, sys

class NoCache(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

os.chdir(os.path.dirname(os.path.abspath(__file__)))
port = int(sys.argv[1]) if len(sys.argv) > 1 else 5190
print(f"Pandoro running at http://localhost:{port}")
http.server.ThreadingHTTPServer(("127.0.0.1", port), NoCache).serve_forever()
