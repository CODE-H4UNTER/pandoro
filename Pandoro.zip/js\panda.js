/* The red panda companion. Every look is a real drawn sprite (no recolouring, no stuck-on shapes).
   It picks a pose for what you're doing, pops between poses with a soft spring, blinks, breathes,
   and the little extras (hearts, notes, zzz, sparkles) float on their own layer. */
(function () {
  const S = window.MOMO_SPRITES, St = window.MomoStore;
  const BODY_H = 440; // the tallest drawn pose; everything is scaled from this

  // old pose names still used around the app -> the new drawings
  const ALIAS = { thinking: 'question', curious: 'question', hood: 'burrito', writing: 'study', reading: 'read', focus: 'read',
    sleepbook: 'sleep', desk: 'laptop', overwhelm: 'surprised', walk: 'run', boba2: 'boba' };
  // a little variety for the happy moments
  const VARIETY = { cheer: ['cheer', 'party', 'yay'], heart: ['heart', 'love'] };
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  const src = (k, v) => `sprites/${k}${v ? '.' + v : ''}.webp`;
  const outfit = () => St.OUTFITS[St.state.avatar.outfit] || St.OUTFITS.red;
  function resolve(k) {
    if (k === 'wave' || k === 'outfit') return outfit().sprite; // greetings are "you", in your outfit
    k = ALIAS[k] || k;
    if (VARIETY[k]) k = pick(VARIETY[k]);
    return S[k] ? k : outfit().sprite;
  }
  const preload = {};
  const load = (url) => preload[url] || (preload[url] = new Promise((r) => { const i = new Image(); i.onload = i.onerror = () => r(i); i.src = url; }));

  // ---------- messages ----------
  const MSG = {
    welcome: ['Welcome back!', 'Oh, hi! Missed you.', 'Ready when you are.', 'Hello again, study buddy!'],
    firstVisit: ["Hi, I'm {name}! Let's study together.", "Press play. I'll keep you company."],
    start: ["Let's get this done.", 'One little step at a time.', "You've got this.", 'Focus time. I brought snacks.', 'Proud of you for showing up.'],
    mid: ["You're doing great.", 'A little progress is still progress.', 'Keep going, slowly is fine.', 'Sip some water?', 'Shoulders down, breathe out.', "We're a good team.", 'Look at you, focusing!', 'I believe in you.'],
    half: ['Halfway there!', 'Half done already. Nice.'],
    almost: ['Five more minutes!', 'Final stretch.'],
    pause: ['Taking a sec? No rush.', "I'll wait right here."],
    short: ['Tiny break time!', 'Boba break!', 'Stretch those paws.', 'Look at something far away for a bit.'],
    long: ['Long break! You earned it.', 'Go for a little walk?', 'Snack time, maybe?'],
    done: ['Yay, session done!', 'Look at you go!', 'Another one! So proud.', 'Tomato harvested!'],
    taskDone: ['Task done!', 'One less thing!', 'Crossed off. Lovely.'],
    breakOver: ["Break's over. Ready?", 'Back to it, gently.'],
    sleep: ['Goodnight...', 'zzz... see you soon.'],
    wake: ['*yawn* Good to see you!', 'Morning! Or whatever time it is.'],
    tap: ['Hehe, that tickles.', 'Hi!', '*happy panda noises*', 'Pat accepted.', "You're nice."],
    reset: ["Fresh start. That's okay.", 'Starting over is still starting.'],
    goal: ['Goal reached! Amazing.', 'You did what you set out to do!'],
    rateGreat: ['Yay! Remember this feeling.', 'A great one! So proud of you.'],
    rateOk: ['Steady is good. Steady adds up.', 'Okay is still a win.'],
    rateMeh: ["That's alright. Some sessions are like that.", 'You still showed up. That counts.'],
    back: ['Oh, there you are!', 'Welcome back. I saved your seat.', 'You came back! Okay, where were we?'],
    switchBack: ['Tap again to switch. This session ends.'],
    resetSure: ['Tap reset again to start over.'],
    skipSure: ['Tap skip again to end this session early.'],
  };

  // ---------- which pose right now ----------
  let temp = null;   // { pose, until }
  let shownKey = '', bubbleT = null, typeT = null, nextCheer = Date.now() + 6 * 60000, milestones = {}, lastSeen = Date.now(), blinkT = null;
  const els = {};

  function basePose(now) {
    const st = St.state, t = st.timer;
    if (st.sleep) return 'sleep';
    if (document.hidden && t.status === 'running' && t.mode === 'focus') return 'peek'; // looking for you
    const coached = window.MomoCoach && window.MomoCoach.pose(); // breaks + check-in: the panda does it with you
    if (coached) return ALIAS[coached] || coached;
    const amb = window.MomoAudio && window.MomoAudio.anyPlaying();
    if (t.status === 'paused') return (now - (t.pausedAt || now)) > 90000 ? 'phone' : 'calm';
    if (t.status === 'running') {
      const dur = window.MomoTimer.total(), elapsed = dur - (t.endAt - now);
      if (t.mode === 'focus') {
        if (elapsed < 10000) return 'idea';
        if (t.endAt - now < 60000) return 'study';
        const slot = Math.floor(elapsed / 300000); // a calm change every 5 minutes
        const rot = amb ? ['music', 'read', 'laptop', 'music', 'study'] : ['read', 'study', 'laptop', 'read', 'study', 'laptop'];
        return rot[slot % rot.length];
      }
      if (elapsed < 12000) return t.mode === 'long' ? 'run' : 'yay';
      if (t.mode === 'long') return ['boba', amb ? 'headphones' : 'phone', 'burrito'][Math.floor(elapsed / 180000) % 3];
      return amb ? 'headphones' : 'boba';
    }
    if (t.mode !== 'focus') return 'boba';
    if (now - lastSeen > 4 * 60000) return 'phone'; // you've been away a while: scrolling, waiting for you
    return outfit().sprite;
  }

  // in sleep mode the panda always comes to the middle, wherever it normally sits
  const place = () => (St.state.sleep ? 'top' : St.state.avatar.place || 'top');
  const host = () => (place() === 'side' ? els.side : els.top);
  const bubbleEl = () => (place() === 'side' ? els.sideBubble : els.bubble);

  function layer(pose) {
    const sp = S[pose], el = document.createElement('div');
    el.className = 'pl';
    el.dataset.pose = pose;
    el.style.width = `calc(var(--ph) * ${(sp.w / BODY_H).toFixed(4)})`;
    const quiet = pose === outfit().sprite && outfit().quiet;
    el.innerHTML = `<div class="pl-body"><img src="${src(pose)}" alt="" draggable="false">${sp.blink ? `<img class="pl-blink" src="${src(pose, 'blink')}" alt="" draggable="false">` : ''}</div>`
      + (sp.deco && !quiet ? `<img class="pl-deco" src="${src(pose, 'deco')}" alt="" draggable="false">` : '');
    return el;
  }

  async function render(force) {
    if (place() === 'off') return;
    const now = Date.now();
    let pose = temp && temp.until > now && !St.state.sleep ? temp.pose : basePose(now); // nothing interrupts sleep
    if (!S[pose]) pose = outfit().sprite;
    const key = [place(), pose].join('|');
    if (key === shownKey && !force) return;
    shownKey = key;
    const el = layer(pose);
    await Promise.all([...el.querySelectorAll('img')].map((i) => load(i.src)));
    if (shownKey !== key) return; // a newer render won
    const h = host();
    const old = [...h.querySelectorAll('.pl')];
    old.forEach((o) => { o.classList.remove('on'); o.classList.add('off'); setTimeout(() => o.remove(), 260); });
    h.appendChild(el);
    h.dataset.pose = pose;
    // the old pose ducks out first, then the new one springs up (no ghosting between two drawings)
    setTimeout(() => requestAnimationFrame(() => el.classList.add('on')), old.length ? 110 : 0);
  }

  // ---------- blinking ----------
  function scheduleBlink() {
    clearTimeout(blinkT);
    blinkT = setTimeout(() => {
      const b = host() && host().querySelector('.pl.on .pl-body');
      if (b && b.querySelector('.pl-blink') && !document.hidden && document.body.dataset.motion !== 'gentle') {
        b.classList.add('blink'); setTimeout(() => b.classList.remove('blink'), 130);
        if (Math.random() < .25) setTimeout(() => { b.classList.add('blink'); setTimeout(() => b.classList.remove('blink'), 120); }, 300); // a double blink now and then
      }
      scheduleBlink();
    }, 2600 + Math.random() * 3800);
  }

  // ---------- the speech bubble: types itself out ----------
  function typeInto(b, text) {
    clearInterval(typeT);
    const gentle = document.body.dataset.motion === 'gentle' || text.length > 90;
    b.textContent = '';
    const span = document.createElement('span'); span.className = 'bubble-text';
    const ghost = document.createElement('span'); ghost.className = 'bubble-ghost'; ghost.textContent = text; // reserves the final size, so the bubble doesn't grow line by line
    b.append(ghost, span);
    if (gentle) { span.textContent = text; return; }
    let i = 0;
    typeT = setInterval(() => { i = Math.min(text.length, i + 2); span.textContent = text.slice(0, i); if (i >= text.length) clearInterval(typeT); }, 28);
  }

  const Panda = {
    MSG, resolve,
    init() {
      els.top = document.getElementById('panda'); els.side = document.getElementById('sidePanda');
      els.bubble = document.getElementById('bubble'); els.sideBubble = document.getElementById('sideBubble');
      const pat = (e) => {
        if (St.state.sleep && window.MomoApp) return window.MomoApp.setSleep(false); // a pat wakes the panda up
        this.hop();
        window.MomoFX && window.MomoFX.hearts(e.clientX, e.clientY);
        if (St.state.timer.status !== 'running') this.react('heart', 'tap', 2600); else this.say('tap');
      };
      document.getElementById('pandaHit').addEventListener('click', pat);
      document.getElementById('sideHit').addEventListener('click', pat);
      ['mousemove', 'keydown', 'touchstart'].forEach((ev) => window.addEventListener(ev, () => { lastSeen = Date.now(); }, { passive: true }));
      // warm the cache with the poses you'll see first
      [outfit().sprite, 'idea', 'read', 'study', 'yay', 'boba', 'sleep', 'heart', 'cheer'].forEach((k) => S[k] && load(src(k)));
      setInterval(() => {
        if (document.body.dataset.pal !== place()) this.applyPlace(); // e.g. sleep mode brings the panda to the middle
        render(); this.cheerLoop();
      }, 1000);
      scheduleBlink();
      this.applyPlace();
    },
    applyPlace() {
      document.body.dataset.pal = place();
      els.top.innerHTML = ''; els.side.innerHTML = ''; shownKey = '';
      render(true);
    },
    refresh() { render(true); },
    hop() {
      const h = host(); if (!h) return;
      h.classList.remove('hop'); void h.offsetWidth; h.classList.add('hop');
      setTimeout(() => h.classList.remove('hop'), 900);
    },
    // briefly show a pose, optionally with a message
    react(pose, msgKey, ms = 3500, hop) {
      temp = { pose: resolve(pose), until: Date.now() + ms }; render();
      if (hop) setTimeout(() => this.hop(), 250);
      if (msgKey) this.say(msgKey);
      setTimeout(() => render(), ms + 30);
    },
    say(keyOrText, ms = 4200) {
      if (!St.state.settings.messages && keyOrText !== 'firstVisit') return;
      if (document.body.classList.contains('ultra')) return; // ultra focus is quiet
      if (place() === 'off') { if (window.MomoApp && ['done', 'goal', 'half'].includes(keyOrText)) window.MomoApp.toast(pick(MSG[keyOrText]), 'cheer', 3000); return; }
      const raw = (MSG[keyOrText] ? pick(MSG[keyOrText]) : keyOrText).replace('{name}', St.state.settings.name || 'Momo');
      const b = bubbleEl();
      [els.bubble, els.sideBubble].forEach((x) => x !== b && x.classList.remove('show'));
      b.classList.remove('show'); void b.offsetWidth;
      typeInto(b, raw);
      b.classList.add('show');
      clearTimeout(bubbleT); bubbleT = setTimeout(() => b.classList.remove('show'), ms + raw.length * 14);
    },
    // cheer you on from time to time during focus: halfway, near the end, and every 7-11 minutes
    cheerLoop() {
      const t = St.state.timer, now = Date.now();
      if (t.status !== 'running' || t.mode !== 'focus' || St.state.sleep) { nextCheer = now + (7 + Math.random() * 4) * 60000; return; }
      const dur = window.MomoTimer.total(), left = t.endAt - now, id = t.startedAt;
      if (!milestones[id]) milestones = { [id]: {} };
      const m = milestones[id];
      if (dur >= 10 * 60000 && !m.half && left <= dur / 2 && left > dur / 2 - 5000) { m.half = 1; this.react('cheer', 'half', 3600, true); return; }
      if (dur >= 15 * 60000 && !m.almost && left <= 5 * 60000 && left > 5 * 60000 - 5000) { m.almost = 1; this.react('idea', 'almost', 3600, true); return; }
      if (now > nextCheer && left > 90000) {
        nextCheer = now + (7 + Math.random() * 4) * 60000;
        // mix the stock lines with ones about what you're actually doing
        const lines = [...MSG.mid], intent = (t.intent || '').trim(), mins = Math.round(left / 60000);
        const todayN = St.state.history.filter((h) => h.completed && St.dayKey(h.end) === St.dayKey()).length;
        const short = intent.length > 28 ? intent.slice(0, 26) + '...' : intent;
        if (intent) lines.push(`Still on “${short}”? You've got this.`, `“${short}” is going well, I can tell.`);
        if (mins >= 2) lines.push(`${mins} minutes to go. Easy.`);
        if (todayN) lines.push(`This is session ${todayN + 1} today. Look at you!`);
        if (!t.slips) lines.push("You haven't wandered off once. Impressive.");
        this.react(pick(['cheer', 'heart', 'idea']), pick(lines), 3800, true);
      }
    },
    spriteThumb(k) { return src(resolve(k)); },
    headSrc(k) { return src(k); },
  };
  window.MomoPanda = Panda;
})();
