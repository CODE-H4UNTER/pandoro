/* Persistent state (localStorage), date helpers and the catalogs of themes / unlockables. */
(function () {
  const KEY = 'pandoro:v1';
  const DAY = 86400000;

  const pad = (n) => String(n).padStart(2, '0');
  const dayKey = (t = Date.now()) => { const d = new Date(t); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
  const dayStart = (t = Date.now()) => { const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); };
  const weekStart = (t = Date.now()) => { const d = new Date(dayStart(t)); const wd = (d.getDay() + 6) % 7; d.setDate(d.getDate() - wd); return d.getTime(); };
  const addDays = (t, n) => { const d = new Date(t); d.setDate(d.getDate() + n); return d.getTime(); };
  const uid = () => Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);

  const PRESETS = {
    classic: { label: 'Classic', sub: '25 / 5', focus: 25, short: 5, long: 15 },
    deep: { label: 'Deep Work', sub: '50 / 10', focus: 50, short: 10, long: 20 },
    extended: { label: 'Extended', sub: '90 / 20', focus: 90, short: 20, long: 30 },
    custom: { label: 'Custom', sub: 'your own' },
  };

  // light palettes; dark variants are derived in panels.js (except Midnight which is hand tuned)
  const THEMES = {
    peach: { label: 'Peach', bg: '#fdf0e6', paper: '#fffaf5', ink: '#5c3f31', soft: '#a07e6c', line: '#f2d8c4', accent: '#ef8a55', pop: '#f9cfb2' },
    matcha: { label: 'Matcha', bg: '#eef1e3', paper: '#fbfaf2', ink: '#3f4a36', soft: '#7c8670', line: '#d7ddc6', accent: '#87a463', pop: '#cbd9ab' },
    strawberry: { label: 'Strawberry Milk', bg: '#fbeeee', paper: '#fffafa', ink: '#5a3a3c', soft: '#9b7a7c', line: '#f1d4d4', accent: '#e8707a', pop: '#f7c8cc' },
    vanilla: { label: 'Vanilla', bg: '#f6efe2', paper: '#fffbf3', ink: '#5a4434', soft: '#9a8572', line: '#e7dbc7', accent: '#bb8654', pop: '#ebd7b9' },
    lavender: { label: 'Lavender', bg: '#f1edf8', paper: '#fcfbff', ink: '#4a4060', soft: '#8c84a2', line: '#ddd5ee', accent: '#9784cf', pop: '#dacff3' },
    midnight: { label: 'Midnight', bg: '#e9e8ee', paper: '#f7f6fa', ink: '#33313e', soft: '#77748a', line: '#d6d4e0', accent: '#7468a8', pop: '#cfc9e6',
      dark: { bg: '#22212a', paper: '#2c2b36', ink: '#ece6f0', soft: '#a39fb2', line: '#3b3948', accent: '#a596d6', pop: '#4d4766' } },
    autumn: { label: 'Autumn', bg: '#f4eadb', paper: '#fdf8ee', ink: '#4e3627', soft: '#927560', line: '#e3d1b6', accent: '#c6612d', pop: '#e8c06a' },
    sakura: { label: 'Sakura', unlock: true, bg: '#fdf1f3', paper: '#fffafb', ink: '#5b3b47', soft: '#a1808c', line: '#f3d6de', accent: '#df8ea6', pop: '#c8e0b0' },
    soda: { label: 'Melon Soda', unlock: true, bg: '#eaf5f1', paper: '#f9fdfb', ink: '#30504a', soft: '#729089', line: '#cfe6df', accent: '#5fb39a', pop: '#f6c6cf' },
    honey: { label: 'Honey Toast', unlock: true, bg: '#fbf3db', paper: '#fffcf1', ink: '#57422a', soft: '#9d8664', line: '#efe0b6', accent: '#dea232', pop: '#f4d38a' },
    starry: { label: 'Starry Night', unlock: true, bg: '#e7ebf4', paper: '#f6f8fc', ink: '#2e3550', soft: '#727b98', line: '#d2d9ea', accent: '#5b6fb5', pop: '#ffd77a',
      dark: { bg: '#1b2036', paper: '#252b45', ink: '#e9ecf8', soft: '#9aa3c4', line: '#343c5c', accent: '#ffd06a', pop: '#4a5584' } },
  };

  // illustrated scenes (generated to match the reference mood boards), each with particles that drift over it
  const SCENES = {
    room: { label: 'Dusk room', fx: 'motes' }, night: { label: 'Night in', fx: 'stars' }, sakura: { label: 'Sakura balcony', fx: 'petals' },
    clouds: { label: 'Dreamy clouds', fx: 'stars' }, forest: { label: 'Meadow', fx: 'leaves' }, sunset: { label: 'Sunset shore', fx: 'motes' },
    space: { label: 'Stargazing', fx: 'stars' },
  };
  const BACKGROUNDS = {
    plain: { label: 'Plain' }, grid: { label: 'Grid paper' }, dots: { label: 'Dot journal' }, lines: { label: 'Lined' },
    gingham: { label: 'Gingham' }, clouds: { label: 'Clouds' }, stars: { label: 'Stars', unlock: true }, hearts: { label: 'Hearts', unlock: true },
  };

  // the panda's look while resting: each one is a real drawn outfit (no recolouring, so nothing ever smears)
  const OUTFITS = {
    red: { label: 'Red hoodie', sprite: 'wave' }, blue: { label: 'Blue hoodie', sprite: 'hi' }, cocoa: { label: 'Cocoa hoodie', sprite: 'stand' },
    lilac: { label: 'Lilac hoodie', sprite: 'love' }, sage: { label: 'Sage hoodie', sprite: 'question', quiet: true }, bookish: { label: 'Round glasses', sprite: 'glasses' },
    beanie: { label: 'Beanie', sprite: 'beanie', unlock: true }, headphones: { label: 'Headphones', sprite: 'headphones', unlock: true },
    sunny: { label: 'Sunny hoodie', sprite: 'yay', unlock: true }, shades: { label: 'Sunglasses', sprite: 'cool', unlock: true },
    explorer: { label: 'Explorer hat', sprite: 'explore', unlock: true }, festive: { label: 'Festive hat', sprite: 'gift', unlock: true },
    sleepy: { label: 'Nightcap', sprite: 'nightcap', unlock: true }, royal: { label: 'Little crown', sprite: 'crown', unlock: true },
  };

  const CURSORS = ['strawberry', 'boba', 'paw', 'sprout', 'system'];

  // the panda's little room: one new thing appears as your total focus sessions grow
  const ROOM = [
    { id: 'mug', label: 'Cocoa mug', at: 1 }, { id: 'books', label: 'Stack of books', at: 3 },
    { id: 'cactus', label: 'Tiny cactus', at: 6 }, { id: 'lamp', label: 'Desk lamp', at: 10 },
    { id: 'frame', label: 'Photo on the wall', at: 15 }, { id: 'radio', label: 'Old radio', at: 21 },
    { id: 'clock', label: 'Wall clock', at: 30 },
  ];
  // paper the UI is painted on
  const PAPERS = { dark: { label: 'Night' }, kraft: { label: 'Kraft' }, light: { label: 'Cream' } };

  const defaults = () => ({
    v: 1,
    settings: { preset: 'classic', focus: 25, short: 5, long: 15, interval: 4, autoBreak: true, autoFocus: false,
      chime: 'bell', chimeVol: 0.6, notify: false, stopAmbientOnEnd: false, idleMode: 'timer', idleDelay: 6,
      cursor: 'strawberry', motion: 'full', messages: true, name: 'Momo' },
    look: { theme: 'lavender', mode: 'dark', accent: null, backdrop: 'scene', scene: 'room', dim: 0.32, bg: 'grid', favs: [] },
    avatar: { outfit: 'red', place: 'top' },
    timer: { mode: 'focus', status: 'idle', endAt: 0, remaining: 25 * 60000, startedAt: 0, cycle: 0, taskId: null, intent: '', slips: 0, awayMs: 0 },
    checkin: null,   // { recId, intent } waiting for "how did it go?"
    coach: { pick: null, day: null, water: 0 },
    tasks: [],
    history: [],
    achievements: {},
    goals: { sessions: { on: true, target: 4 }, minutes: { on: false, target: 120 }, tasks: { on: false, target: 3 }, days: { on: true, target: 5 }, celebrated: {} },
    ambient: { master: 0.7, vol: {}, on: [] },
    sleep: false,
    meta: { firstSeen: Date.now(), lastDay: null, roomSeen: 0 },
  });

  function merge(base, saved) {
    if (!saved || typeof saved !== 'object' || Array.isArray(base)) return saved === undefined ? base : saved;
    const out = { ...base };
    for (const k of Object.keys(saved)) {
      out[k] = (base[k] && typeof base[k] === 'object' && !Array.isArray(base[k])) ? merge(base[k], saved[k]) : saved[k];
    }
    return out;
  }

  function load() {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) return merge(defaults(), JSON.parse(raw));
    } catch (e) { console.warn('momo: could not read saved data', e); }
    return defaults();
  }

  const state = load();
  if (!OUTFITS[state.avatar.outfit]) state.avatar.outfit = 'red'; // older saves had hoodie colours instead
  ['hoodie', 'pattern', 'head', 'face', 'idle'].forEach((k) => delete state.avatar[k]);
  let saveT = null, frozen = false;
  const listeners = new Set();
  const Store = {
    state, KEY, DAY, PRESETS, THEMES, SCENES, BACKGROUNDS, OUTFITS, CURSORS, ROOM, PAPERS,
    dayKey, dayStart, weekStart, addDays, uid, pad,
    save(now) {
      clearTimeout(saveT);
      if (frozen) return; // a reset / import is reloading the page; don't write old state back
      const write = () => { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { console.warn('momo: save failed', e); } };
      if (now) write(); else saveT = setTimeout(write, 120);
    },
    // notify UI parts that something changed
    emit(topic) { this.save(); listeners.forEach((fn) => fn(topic)); },
    on(fn) { listeners.add(fn); },
    reset() { frozen = true; clearTimeout(saveT); localStorage.removeItem(KEY); location.reload(); },
    exportJSON() { return JSON.stringify(state, null, 2); },
    importJSON(text) {
      const data = JSON.parse(text);
      if (!data || data.v !== 1 || !data.settings) throw new Error('Not a Pandoro backup');
      frozen = true; clearTimeout(saveT);
      localStorage.setItem(KEY, JSON.stringify(merge(defaults(), data)));
      location.reload();
    },
    // reward catalogs: is item unlocked?
    unlocked(kind, id) {
      const cat = { theme: THEMES, bg: BACKGROUNDS, outfit: OUTFITS }[kind];
      if (!cat || !cat[id]) return false;
      if (!cat[id].unlock) return true;
      return !!(window.MomoRewards && window.MomoRewards.isRewardUnlocked(kind, id));
    },
  };
  window.addEventListener('pagehide', () => Store.save(true));
  window.MomoStore = Store;
})();
