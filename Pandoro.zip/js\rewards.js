/* Achievements (with cosmetic rewards) and gentle daily / weekly goals. Nothing is ever taken away. */
(function () {
  const St = window.MomoStore;
  const A = [
    { id: 'first', title: 'First Steps', desc: 'Complete your first pomodoro', pose: 'idea', test: (m) => m.sessions >= 1, rewards: [['outfit', 'beanie']] },
    { id: 'five', title: 'Getting Started', desc: 'Complete 5 sessions', pose: 'read', test: (m) => m.sessions >= 5, rewards: [['outfit', 'headphones']] },
    { id: 'ten', title: 'Little by Little', desc: 'Complete 10 sessions', pose: 'yay', test: (m) => m.sessions >= 10, rewards: [['outfit', 'sunny']] },
    { id: 'day4', title: 'Focus Mode', desc: 'Complete 4 sessions in one day', pose: 'laptop', test: (m) => m.bestDaySessions >= 4, rewards: [['outfit', 'shades']] },
    { id: 'hour', title: 'Hour of Power', desc: 'Focus for 60 minutes in one day', pose: 'study', test: (m) => m.bestDayMinutes >= 60, rewards: [['outfit', 'explorer'], ['theme', 'honey']] },
    { id: 'streak3', title: 'Consistency', desc: 'Study 3 days in a row', pose: 'run', test: (m) => m.bestStreak >= 3, rewards: [['theme', 'sakura']] },
    { id: 'tasks10', title: 'Task Tamer', desc: 'Complete 10 tasks', pose: 'cheer', test: (m) => m.tasksDone >= 10, rewards: [['outfit', 'festive']] },
    { id: 'goal', title: 'Goal Getter', desc: 'Reach all of a day\'s goals', pose: 'heart', test: (m) => m.goalDays >= 1, rewards: [['bg', 'hearts'], ['theme', 'soda']] },
    { id: 'streak7', title: 'Dedicated', desc: 'Keep a 7-day streak', pose: 'boba', test: (m) => m.bestStreak >= 7, rewards: [['outfit', 'sleepy'], ['bg', 'stars']] },
    { id: 'fifty', title: 'Bookworm', desc: 'Complete 50 sessions', pose: 'sleep', test: (m) => m.sessions >= 50, rewards: [['outfit', 'royal']] },
    { id: 'hundred', title: 'Study Legend', desc: 'Complete 100 sessions', pose: 'party', test: (m) => m.sessions >= 100, rewards: [['theme', 'starry']] },
  ];
  const CAT = { theme: 'THEMES', bg: 'BACKGROUNDS', outfit: 'OUTFITS' };
  const KIND = { theme: 'theme', bg: 'background', outfit: 'outfit' };
  const rewardLabel = ([k, id]) => `${St[CAT[k]][id].label} ${KIND[k]}`;

  const Rewards = {
    LIST: A, rewardLabel,
    isRewardUnlocked(kind, id) { return A.some((a) => St.state.achievements[a.id] && a.rewards.some(([k, i]) => k === kind && i === id)); },
    unlockedBy(kind, id) { return A.find((a) => a.rewards.some(([k, i]) => k === kind && i === id)); },
    // evaluate and return newly earned achievements
    check() {
      const m = window.MomoStats.metrics(), fresh = [];
      A.forEach((a) => { if (!St.state.achievements[a.id] && a.test(m)) { St.state.achievements[a.id] = Date.now(); fresh.push(a); } });
      if (fresh.length) St.emit('rewards');
      return fresh;
    },
    // ---------- goals ----------
    GOALS: {
      sessions: { label: 'Pomodoros today', unit: '', min: 1, max: 20 },
      minutes: { label: 'Focus minutes today', unit: 'min', min: 10, max: 600, step: 10 },
      tasks: { label: 'Tasks done today', unit: '', min: 1, max: 20 },
      days: { label: 'Study days this week', unit: 'days', min: 1, max: 7 },
    },
    goalProgress() {
      const m = window.MomoStats.metrics(), g = St.state.goals;
      const val = { sessions: m.todaySessions, minutes: m.todayMinutes, tasks: m.todayTasks, days: m.weekDays };
      return Object.keys(this.GOALS).filter((k) => g[k].on).map((k) => ({ id: k, ...this.GOALS[k], value: val[k], target: g[k].target, done: val[k] >= g[k].target }));
    },
    // returns goals newly reached (celebrated once per day / week)
    checkGoals() {
      const g = St.state.goals, today = St.dayKey(), week = St.dayKey(St.weekStart()), fresh = [];
      const prog = this.goalProgress();
      prog.forEach((p) => { const key = (p.id === 'days' ? week : today) + ':' + p.id; if (p.done && !g.celebrated[key]) { g.celebrated[key] = 1; fresh.push(p); } });
      const daily = prog.filter((p) => p.id !== 'days');
      if (daily.length && daily.every((p) => p.done) && !g.celebrated[today + ':all']) { g.celebrated[today + ':all'] = 1; g.goalDays = (g.goalDays || 0) + 1; }
      // keep the celebration log small
      const keys = Object.keys(g.celebrated); if (keys.length > 200) keys.slice(0, keys.length - 200).forEach((k) => delete g.celebrated[k]);
      if (fresh.length) St.save();
      return fresh;
    },
  };
  window.MomoRewards = Rewards;
})();
