/* The check-in faces (the panda's own drawn expressions) and a brush underline. */
(function () {
  const INK = '#4a3029';
  const head = (k) => `<img class="head-face" src="sprites/${k}.webp" alt="" draggable="false">`;
  const FACES = { meh: head('h_ouch'), ok: head('h_hm'), great: head('h_love') };
  // a soft brush stroke, used as a CSS mask under headings
  const brush = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 120 12' preserveAspectRatio='none'%3E%3Cpath d='M3 8.2C25 4.6 48 9.6 70 6.6S104 4.4 117 6.4c1.6.3 1.4 2.4-.2 2.4-16 .3-30 2.4-48 2.5S22 9.6 4 10.6c-2 .1-2.6-2.1-1-2.4z' fill='%23000'/%3E%3C/svg%3E")`;
  document.documentElement.style.setProperty('--brush', brush);
  window.MomoDoodle = { FACES, INK };
})();
