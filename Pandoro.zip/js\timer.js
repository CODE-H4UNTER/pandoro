/* Pomodoro timer. Timing is timestamp based (endAt), so it stays exact in background tabs
   and survives refreshes; missed completions are caught up on load.
   t.extra = minutes added or taken off this session (tap the clock). */
(function () {
  const St = window.MomoStore;
  const T = () => St.state.timer, S = () => St.state.settings;
  let hooks = {};
  let tickT = null, endT = null;
  const MIN_LEFT = 30000, MAX_LEFT = 4 * 3600000;

  const Timer = {
    duration(mode) { const s = S(); return Math.round((mode === 'focus' ? s.focus : mode === 'short' ? s.short : s.long) * 60000); },
    // the length of the current session, including any time added or taken off
    total() { const t = T(); return Math.max(MIN_LEFT, this.duration(t.mode) + (t.extra || 0)); },
    remaining(now = Date.now()) { const t = T(); return t.status === 'running' ? Math.max(0, t.endAt - now) : t.remaining; },
    init(h) {
      hooks = h;
      const t = T();
      if (t.status === 'idle') t.remaining = this.total();
      this.catchUp(true);
      tickT = setInterval(() => this.tick(), 250);
      document.addEventListener('visibilitychange', () => this.tick());
      this.arm();
    },
    arm() { clearTimeout(endT); const t = T(); if (t.status === 'running') endT = setTimeout(() => this.tick(), Math.max(0, t.endAt - Date.now()) + 20); },
    tick() {
      const t = T();
      if (t.status === 'running' && Date.now() >= t.endAt) this.complete(t.endAt, false);
      hooks.onTick && hooks.onTick();
    },
    catchUp(silent) {
      let guard = 0;
      while (T().status === 'running' && Date.now() >= T().endAt && guard++ < 12) this.complete(T().endAt, silent);
    },
    start(at = Date.now()) {
      const t = T(); if (t.status === 'running') return;
      if (t.status === 'idle') { t.remaining = this.total(); t.startedAt = at; t.slips = 0; t.awayMs = 0; if (t.mode === 'focus') t.parked = 0; }
      if (t.status === 'paused' && t.pausedAt) t.pausedTotal = (t.pausedTotal || 0) + (at - t.pausedAt);
      t.endAt = at + t.remaining; t.status = 'running'; t.pausedAt = 0;
      St.emit('timer'); this.arm(); hooks.onStart && hooks.onStart(t.mode);
    },
    pause() {
      const t = T(); if (t.status !== 'running') return;
      t.remaining = Math.max(0, t.endAt - Date.now()); t.status = 'paused'; t.pausedAt = Date.now();
      clearTimeout(endT); St.emit('timer'); hooks.onPause && hooks.onPause();
    },
    toggle() { T().status === 'running' ? this.pause() : this.start(); },
    clear(t) { t.status = 'idle'; t.extra = 0; t.remaining = this.total(); t.endAt = 0; t.pausedAt = 0; t.pausedTotal = 0; },
    reset() { const t = T(); this.clear(t); clearTimeout(endT); St.emit('timer'); hooks.onReset && hooks.onReset(); },
    setMode(mode) { const t = T(); t.mode = mode; this.clear(t); clearTimeout(endT); St.emit('timer'); },
    // add (ms > 0) or take off (ms < 0) time from the current session; returns what actually changed
    adjust(ms) {
      const t = T(), rem = this.remaining();
      const next = Math.max(MIN_LEFT, Math.min(MAX_LEFT, rem + ms)), delta = next - rem;
      if (!delta) return 0;
      if (t.status === 'running') { t.endAt += delta; this.arm(); } else t.remaining = next;
      t.extra = (t.extra || 0) + delta;
      St.emit('timer');
      return delta;
    },
    syncDurations() { const t = T(); if (t.status === 'idle') { t.remaining = this.total(); St.emit('timer'); } },
    skip() {
      const t = T(), now = Date.now();
      if (t.mode === 'focus' && t.status !== 'idle') {
        const studied = this.total() - this.remaining(now);
        if (studied >= 60000) hooks.onRecord && hooks.onRecord({ start: t.startedAt || now - studied, end: now, min: Math.round(studied / 60000), completed: false, taskId: t.taskId });
      }
      this.advance(now, false, true);
    },
    complete(at, silent) {
      const t = T();
      if (t.mode === 'focus') {
        t.cycle = (t.cycle || 0) + 1;
        const len = this.total();
        hooks.onRecord && hooks.onRecord({ start: t.startedAt || at - len, end: at, min: Math.round(len / 60000), completed: true, taskId: t.taskId });
      }
      hooks.onComplete && hooks.onComplete(t.mode, silent, at);
      this.advance(at, true, false, silent);
    },
    advance(at, natural, skipped, silent) {
      const t = T(), from = t.mode, s = S();
      let next;
      if (from === 'focus') next = (t.cycle > 0 && t.cycle % s.interval === 0 && !skipped) ? 'long' : 'short';
      else { next = 'focus'; if (from === 'long') t.cycle = 0; }
      t.mode = next; this.clear(t);
      St.emit('timer');
      const auto = next === 'focus' ? s.autoFocus : s.autoBreak;
      if (natural && auto && !St.state.sleep) this.start(at);
      else this.arm();
      hooks.onAdvance && hooks.onAdvance(from, next, natural, silent);
    },
  };
  window.MomoTimer = Timer;
})();
