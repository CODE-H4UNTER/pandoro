/* Hand-drawn style SVG art that complements the supplied panda illustrations:
   flat soft fills, rounded shapes, no outlines on icons (matching the feature icons). */
(function () {
  const A = {};

  // ---------- small UI glyphs (inherit currentColor) ----------
  const g = (body, vb = 24) => `<svg viewBox="0 0 ${vb} ${vb}" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">${body}</svg>`;
  A.glyph = {
    play: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8.2 5.3c-.9-.6-2.2 0-2.2 1.1v11.2c0 1.1 1.3 1.7 2.2 1.1l8.6-5.6c.8-.5.8-1.7 0-2.2z" fill="currentColor"/></svg>`,
    pause: `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5.5" y="5" width="4.6" height="14" rx="2.3" fill="currentColor"/><rect x="13.9" y="5" width="4.6" height="14" rx="2.3" fill="currentColor"/></svg>`,
    reset: g(`<path d="M5 12a7 7 0 1 0 2.3-5.2"/><path d="M5.2 3.8v3.6h3.6"/>`),
    skip: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.4 6.2c-.8-.5-1.9.1-1.9 1v9.6c0 1 1.1 1.5 1.9 1l7-4.8c.7-.5.7-1.5 0-2z" fill="currentColor"/><rect x="15.6" y="5.5" width="3.6" height="13" rx="1.8" fill="currentColor"/></svg>`,
    close: g(`<path d="M7 7l10 10M17 7L7 17"/>`),
    plus: g(`<path d="M12 6v12M6 12h12"/>`),
    minus: g(`<path d="M6 12h12"/>`),
    up: g(`<path d="M6 15l6-6 6 6"/>`),
    pencil: g(`<path d="M4.5 19.5l1.2-4.3L15.8 5.1a2.1 2.1 0 0 1 3 3L8.7 18.2z"/><path d="M13.6 7.3l3 3"/>`, 24),
    list: g(`<path d="M9 7h10M9 12h10M9 17h7"/><path d="M4.8 7h.4M4.8 12h.4M4.8 17h.4"/>`),
    paper: g(`<path d="M6.5 3.5h7.5l4.5 4.5v12.5h-12z"/><path d="M14 3.5V8h4.5"/><path d="M9 12.5h6M9 16h4.5"/>`),
    gear: `<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M10.3 2.6a1.8 1.8 0 0 1 3.4 0l.4 1.2a1.8 1.8 0 0 0 2.4 1l1.1-.6a1.8 1.8 0 0 1 2.4 2.4l-.6 1.1a1.8 1.8 0 0 0 1 2.4l1.2.4a1.8 1.8 0 0 1 0 3.4l-1.2.4a1.8 1.8 0 0 0-1 2.4l.6 1.1a1.8 1.8 0 0 1-2.4 2.4l-1.1-.6a1.8 1.8 0 0 0-2.4 1l-.4 1.2a1.8 1.8 0 0 1-3.4 0l-.4-1.2a1.8 1.8 0 0 0-2.4-1l-1.1.6a1.8 1.8 0 0 1-2.4-2.4l.6-1.1a1.8 1.8 0 0 0-1-2.4l-1.2-.4a1.8 1.8 0 0 1 0-3.4l1.2-.4a1.8 1.8 0 0 0 1-2.4l-.6-1.1a1.8 1.8 0 0 1 2.4-2.4l1.1.6a1.8 1.8 0 0 0 2.4-1zM12 8.6a3.4 3.4 0 1 0 0 6.8 3.4 3.4 0 0 0 0-6.8z"/></svg>`,
    check: g(`<path d="M6 12.5l4 4 8-9"/>`),
    trash: g(`<path d="M5 7h14M10 7V5h4v2M7 7l1 12h8l1-12"/>`, 24),
    edit: g(`<path d="M5 19l1-4L15.5 5.5a2 2 0 0 1 3 3L9 18z"/>`),
    lock: `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="10.5" width="14" height="10" rx="3" fill="currentColor"/><path d="M8.5 10.5V8a3.5 3.5 0 0 1 7 0v2.5" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>`,
    chevron: g(`<path d="M9 6l6 6-6 6"/>`),
    popout: g(`<rect x="3.5" y="5" width="17" height="14" rx="3"/><rect x="11.5" y="11" width="6.5" height="5.5" rx="1.5" fill="currentColor"/>`),
    note: g(`<path d="M6 4.5h9l3.5 3.5V19a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V5.5a1 1 0 0 1 1-1z"/><path d="M8.5 11h7M8.5 14.5h4.5"/>`),
    expand: g(`<path d="M4.5 9V5.5a1 1 0 0 1 1-1H9M15 4.5h3.5a1 1 0 0 1 1 1V9M19.5 15v3.5a1 1 0 0 1-1 1H15M9 19.5H5.5a1 1 0 0 1-1-1V15"/>`),
    shrink: g(`<path d="M9 4.5V8a1 1 0 0 1-1 1H4.5M19.5 9H16a1 1 0 0 1-1-1V4.5M15 19.5V16a1 1 0 0 1 1-1h3.5M4.5 15H8a1 1 0 0 1 1 1v3.5"/>`),
    target: g(`<circle cx="12" cy="12" r="7"/><circle cx="12" cy="12" r="2.5" fill="currentColor"/>`),
    heart: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z" fill="currentColor"/></svg>`,
  };

  // ---------- dock icon for sounds (flat, like the feature icons) ----------
  A.headphonesIcon = `<svg viewBox="0 0 64 64" aria-hidden="true">
    <path d="M12 38v-6a20 20 0 0 1 40 0v6" fill="none" stroke="#e8875e" stroke-width="6" stroke-linecap="round"/>
    <rect x="7" y="34" width="14" height="20" rx="7" fill="#f2a36f"/><rect x="43" y="34" width="14" height="20" rx="7" fill="#f2a36f"/>
    <rect x="10" y="38" width="6" height="12" rx="3" fill="#fbd3b0"/><rect x="48" y="38" width="6" height="12" rx="3" fill="#fbd3b0"/>
    <path d="M30 16c3-1 7-.5 9 1" stroke="#fbd3b0" stroke-width="3" stroke-linecap="round" fill="none" opacity=".8"/></svg>`;

  // ---------- ambient sound tiles ----------
  A.sound = {
    rain: `<svg viewBox="0 0 64 64"><path d="M18 36a10 10 0 0 1 1-20 13 13 0 0 1 25 2 9 9 0 0 1 2 18z" fill="#cfe0ef"/><path d="M24 22a8 8 0 0 1 10-4" stroke="#fff" stroke-width="3" stroke-linecap="round" fill="none"/><path d="M22 44l-2 6M32 44l-2 6M42 44l-2 6" stroke="#7fb2de" stroke-width="4" stroke-linecap="round"/></svg>`,
    thunder: `<svg viewBox="0 0 64 64"><path d="M18 36a10 10 0 0 1 1-20 13 13 0 0 1 25 2 9 9 0 0 1 2 18z" fill="#b9b6d0"/><path d="M33 36l-7 11h6l-3 10 10-14h-6l4-7z" fill="#ffc94a"/><path d="M20 44l-2 5M44 44l-2 5" stroke="#8c9ac8" stroke-width="4" stroke-linecap="round"/></svg>`,
    fire: `<svg viewBox="0 0 64 64"><path d="M32 8c3 8 14 14 14 28a14 14 0 0 1-28 0c0-7 4-11 6-14 1 5 3 7 5 7-1-8 0-15 3-21z" fill="#f2884f"/><path d="M32 30c2 4 7 6 7 12a7 7 0 0 1-14 0c0-4 3-6 4-8 1 2 2 3 3 3z" fill="#ffc94a"/><rect x="14" y="52" width="36" height="6" rx="3" fill="#a86a4c"/></svg>`,
    forest: `<svg viewBox="0 0 64 64"><path d="M32 6c9 8 16 20 16 30a16 16 0 0 1-32 0c0-10 7-22 16-30z" fill="#9cc27a"/><path d="M26 22c2-3 4-6 6-8" stroke="#c9e1a8" stroke-width="3" stroke-linecap="round" fill="none"/><rect x="29" y="44" width="6" height="14" rx="3" fill="#a86a4c"/></svg>`,
    ocean: `<svg viewBox="0 0 64 64"><path d="M6 34c6-6 12-6 18 0s12 6 18 0 12-6 16-2v22H6z" fill="#8fc6dc"/><path d="M6 46c6-5 12-5 18 0s12 5 18 0 12-5 16-1v13H6z" fill="#5fa8c9"/><circle cx="46" cy="16" r="7" fill="#ffd27a"/></svg>`,
    cafe: `<svg viewBox="0 0 64 64"><path d="M14 26h30v14a13 13 0 0 1-13 13h-4a13 13 0 0 1-13-13z" fill="#f4ddc4"/><path d="M44 30h3a6 6 0 0 1 0 12h-4" stroke="#f4ddc4" stroke-width="5" fill="none"/><rect x="14" y="26" width="30" height="6" fill="#b47a55"/><path d="M24 12c-3 3 3 5 0 8M33 12c-3 3 3 5 0 8" stroke="#d9c3b4" stroke-width="3" stroke-linecap="round" fill="none"/><rect x="10" y="54" width="40" height="5" rx="2.5" fill="#e2c3a6"/></svg>`,
    white: `<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="22" fill="#e9e6ef"/><g fill="#fff"><circle cx="24" cy="24" r="3"/><circle cx="38" cy="22" r="2"/><circle cx="30" cy="34" r="2.5"/><circle cx="42" cy="38" r="3"/><circle cx="22" cy="40" r="2"/></g></svg>`,
    pink: `<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="22" fill="#f8cdd5"/><path d="M18 32c4-6 8-6 12 0s8 6 12 0 6-4 6-2" stroke="#fff" stroke-width="3.5" stroke-linecap="round" fill="none"/></svg>`,
    brown: `<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="22" fill="#dcbca4"/><path d="M16 34c5-3 10-3 16 0s11 3 16 0" stroke="#fff" stroke-width="3.5" stroke-linecap="round" fill="none"/></svg>`,
    clock: `<svg viewBox="0 0 64 64"><circle cx="32" cy="34" r="21" fill="#f3e2c8"/><circle cx="32" cy="34" r="21" fill="none" stroke="#d9b98f" stroke-width="3"/><path d="M32 22v12l8 5" stroke="#7a5446" stroke-width="3.5" stroke-linecap="round" fill="none"/><path d="M17 15l-4 4M47 15l4 4" stroke="#d9b98f" stroke-width="4" stroke-linecap="round"/></svg>`,
    lofi: `<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="23" fill="#4f3c3a"/><circle cx="32" cy="32" r="17" fill="none" stroke="#6b5552" stroke-width="2"/><circle cx="32" cy="32" r="9" fill="#f2884f"/><circle cx="32" cy="32" r="2.5" fill="#fff4ea"/><path d="M22 18a17 17 0 0 1 8-3" stroke="#8c7470" stroke-width="2.5" stroke-linecap="round" fill="none"/></svg>`,
  };

  // ---------- cursors (32px, hotspot near the tip) ----------
  const cur = (svg) => `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
  const strawberry = (big) => `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
    <g transform="rotate(140 16 17)${big ? ' translate(16 17) scale(1.08) translate(-16 -17)' : ''}">
      <path d="M16 29.5C9 25.5 4.6 18.6 5.6 12.6 6.4 8.4 11 7.4 16 8.4c5-1 9.6 0 10.4 4.2 1 6-3.4 12.9-10.4 16.9z" fill="#f2646d" stroke="#7a2b33" stroke-width="1.4" stroke-linejoin="round"/>
      <path d="M9 13c.5-1.6 2-2.3 3.6-2.3" stroke="#ffb3b8" stroke-width="1.6" stroke-linecap="round" fill="none"/>
      <g fill="#ffe7b8"><ellipse cx="12" cy="16" rx=".9" ry="1.2"/><ellipse cx="17" cy="14.6" rx=".9" ry="1.2"/><ellipse cx="21" cy="17" rx=".9" ry="1.2"/><ellipse cx="14.5" cy="20.5" rx=".9" ry="1.2"/><ellipse cx="19" cy="21.5" rx=".9" ry="1.2"/><ellipse cx="16.5" cy="25" rx=".8" ry="1.1"/></g>
      <path d="M16 9.6l-3.6-3.2 2.4.4L13.4 3.6l2.6 2.6 2.6-2.6-1.4 3.2 2.4-.4z" fill="#8cc06a" stroke="#3f6b2c" stroke-width="1.1" stroke-linejoin="round"/>
    </g>${big ? '<path d="M27 4l.9 2.1 2.1.9-2.1.9L27 10l-.9-2.1L24 7l2.1-.9z" fill="#ffc94a" stroke="#9b6b12" stroke-width=".8"/>' : ''}</svg>`;
  const boba = (big) => `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
    <g transform="rotate(-28 16 16)${big ? ' translate(16 16) scale(1.08) translate(-16 -16)' : ''}">
      <path d="M17 1.5l-1.2 9" stroke="#5a3b35" stroke-width="2.6" stroke-linecap="round"/>
      <path d="M8.5 10h15l-2 18a2.5 2.5 0 0 1-2.5 2.2h-6A2.5 2.5 0 0 1 10.5 28z" fill="#f4dcc2" stroke="#6b4636" stroke-width="1.3" stroke-linejoin="round"/>
      <rect x="7.5" y="8.6" width="17" height="3" rx="1.5" fill="#fff4ea" stroke="#6b4636" stroke-width="1.2"/>
      <g fill="#5a3b35"><circle cx="13" cy="25" r="1.4"/><circle cx="16.5" cy="26.6" r="1.4"/><circle cx="19.5" cy="24.5" r="1.4"/><circle cx="14.8" cy="22.4" r="1.2"/></g>
    </g></svg>`;
  const paw = (big) => `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><g transform="rotate(-18 16 16)${big ? ' translate(16 16) scale(1.08) translate(-16 -16)' : ''}" stroke="#3a2420" stroke-width="1.2">
    <ellipse cx="16" cy="21" rx="7.5" ry="6.5" fill="#6b3d33"/><ellipse cx="16" cy="21.5" rx="4" ry="3.4" fill="#c47e6e" stroke="none"/>
    <ellipse cx="7.8" cy="13" rx="2.8" ry="3.4" fill="#6b3d33"/><ellipse cx="13" cy="8.5" rx="2.8" ry="3.4" fill="#6b3d33"/><ellipse cx="19" cy="8.5" rx="2.8" ry="3.4" fill="#6b3d33"/><ellipse cx="24.2" cy="13" rx="2.8" ry="3.4" fill="#6b3d33"/></g></svg>`;
  const sprout = (big) => `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><g${big ? ' transform="translate(16 16) scale(1.08) translate(-16 -16)"' : ''}>
    <path d="M5 4c8-1 12 3 12 10C10 15 5 11 5 4z" fill="#a9cf7f" stroke="#476b2e" stroke-width="1.3" stroke-linejoin="round"/>
    <path d="M17 14c0-6 4-9 11-8 0 6-4 9-11 8z" fill="#8cc06a" stroke="#476b2e" stroke-width="1.3" stroke-linejoin="round"/>
    <path d="M17 14v10" stroke="#476b2e" stroke-width="1.6" stroke-linecap="round"/><ellipse cx="17" cy="26" rx="6" ry="3.5" fill="#d79a6a" stroke="#7a4b2e" stroke-width="1.2"/></g></svg>`;
  A.cursors = {
    strawberry: { label: 'Strawberry', base: cur(strawberry(false)) + ' 7 9', ptr: cur(strawberry(true)) + ' 7 9', svg: strawberry(false) },
    boba: { label: 'Boba', base: cur(boba(false)) + ' 13 2', ptr: cur(boba(true)) + ' 13 2', svg: boba(false) },
    paw: { label: 'Paw', base: cur(paw(false)) + ' 9 6', ptr: cur(paw(true)) + ' 9 6', svg: paw(false) },
    sprout: { label: 'Sprout', base: cur(sprout(false)) + ' 5 4', ptr: cur(sprout(true)) + ' 5 4', svg: sprout(false) },
    system: { label: 'System', base: 'auto', ptr: 'pointer', svg: null },
  };

  // ---------- background doodles ----------
  A.doodle = {
    star: `<svg viewBox="0 0 40 40"><path d="M20 4l4.6 9.6 10.4 1.4-7.6 7.2 1.9 10.4L20 27.6l-9.3 5 1.9-10.4L5 15l10.4-1.4z" fill="currentColor"/></svg>`,
    sparkle: `<svg viewBox="0 0 40 40"><path d="M20 3c1.6 9 4 11.4 13 13-9 1.6-11.4 4-13 13-1.6-9-4-11.4-13-13 9-1.6 11.4-4 13-13z" fill="currentColor"/></svg>`,
    cloud: `<svg viewBox="0 0 80 44"><path d="M18 40a13 13 0 0 1 1-26 17 17 0 0 1 32-2 12 12 0 0 1 12 12 8 8 0 0 1-1 16z" fill="currentColor"/></svg>`,
    heart: `<svg viewBox="0 0 40 40"><path d="M20 34S5 25 5 14a8 8 0 0 1 15-4 8 8 0 0 1 15 4c0 11-15 20-15 20z" fill="currentColor"/></svg>`,
    leaf: `<svg viewBox="0 0 40 40"><path d="M6 34C6 16 16 6 34 6c0 18-10 28-28 28z" fill="currentColor"/><path d="M10 30L26 14" stroke="var(--bg)" stroke-width="2" stroke-linecap="round" opacity=".5"/></svg>`,
    dot: `<svg viewBox="0 0 20 20"><circle cx="10" cy="10" r="7" fill="currentColor"/></svg>`,
  };

  // ---------- accessories drawn on top of the sprite ----------
  // anchor fractions are relative to sprite width / height
  A.accessory = function (kind, an, W, H) {
    if (!kind || kind === 'none' || !an) return '';
    const cx = an.cx * W, top = an.top * H, hw = an.hw * W;
    const e1 = an.ex1 * W, e2 = an.ex2 * W, ey = an.ey * H, d = e2 - e1, em = (e1 + e2) / 2;
    const rot = (s, ox = cx, oy = top) => `<g transform="rotate(${an.tilt || 0} ${ox} ${oy})">${s}</g>`;
    switch (kind) {
      case 'glasses': {
        if (an.noFace) return '';
        const r = d * 0.33, sw = Math.max(2, r * 0.2);
        return rot(`<g fill="rgba(255,255,255,.22)" stroke="#3b2a26" stroke-width="${sw}">
          <circle cx="${e1}" cy="${ey}" r="${r}"/><circle cx="${e2}" cy="${ey}" r="${r}"/></g>
          <path d="M${e1 + r} ${ey - r * .15}q${(d - 2 * r) / 2} ${-r * .35} ${d - 2 * r} 0" stroke="#3b2a26" stroke-width="${sw}" fill="none" stroke-linecap="round"/>
          <path d="M${e1 - r * .55} ${ey - r * .35}a${r * .7} ${r * .7} 0 0 1 ${r * .45} -${r * .4}M${e2 - r * .55} ${ey - r * .35}a${r * .7} ${r * .7} 0 0 1 ${r * .45} -${r * .4}" stroke="#fff" stroke-width="${sw * .8}" fill="none" stroke-linecap="round" opacity=".8"/>`, em, ey);
      }
      case 'blush': {
        if (an.noFace) return '';
        return rot(`<g fill="#ff8f9c" opacity=".55"><ellipse cx="${e1 - d * .2}" cy="${ey + d * .42}" rx="${d * .19}" ry="${d * .11}"/><ellipse cx="${e2 + d * .2}" cy="${ey + d * .42}" rx="${d * .19}" ry="${d * .11}"/></g>`, em, ey);
      }
      case 'sparkle': {
        const s = (x, y, k) => `<path d="M${x} ${y - k}c${k * .18} ${k * .62} ${k * .38} ${k * .82} ${k} ${k}c-${k * .62} ${k * .18}-${k * .82} ${k * .38}-${k} ${k}c-${k * .18}-${k * .62}-${k * .38}-${k * .82}-${k}-${k}c${k * .62}-${k * .18} ${k * .82}-${k * .38} ${k}-${k}z" fill="#ffc94a"/>`;
        return `<g class="acc-twinkle">${s(e2 + d * .75, ey - d * .65, d * .2)}${s(e1 - d * .7, ey - d * .25, d * .13)}${s(e2 + d * .95, ey - d * .05, d * .1)}</g>`;
      }
      case 'bow': {
        if (an.noHat) return '';
        const x = cx - hw * .26, y = top + hw * .09, k = hw * .13;
        return rot(`<g transform="rotate(-18 ${x} ${y})"><path d="M${x} ${y}C${x - k * 1.6} ${y - k * 1.3} ${x - k * 1.9} ${y + k * 1.2} ${x} ${y}z" fill="#f37b8b"/><path d="M${x} ${y}C${x + k * 1.6} ${y - k * 1.3} ${x + k * 1.9} ${y + k * 1.2} ${x} ${y}z" fill="#f37b8b"/>
          <path d="M${x - k * .95} ${y - k * .25}c${k * .3}-${k * .3} ${k * .6}-${k * .35} ${k * .8}-${k * .2}" stroke="#ffc2ca" stroke-width="${k * .18}" stroke-linecap="round" fill="none"/>
          <circle cx="${x}" cy="${y}" r="${k * .34}" fill="#e0606f"/></g>`);
      }
      case 'flower': {
        if (an.noHat) return '';
        const x = cx + hw * .24, y = top + hw * .1, r = hw * .055;
        let p = '';
        for (let i = 0; i < 5; i++) { const a = i * 72 * Math.PI / 180; p += `<circle cx="${x + Math.cos(a) * r * 1.3}" cy="${y + Math.sin(a) * r * 1.3}" r="${r}" fill="#fff7f2"/>`; }
        return rot(`${p}<circle cx="${x}" cy="${y}" r="${r * .75}" fill="#ffc94a"/>`);
      }
      case 'beanie': {
        if (an.noHat) return '';
        const w = hw * .52, x = cx - w / 2, y = top + hw * .1, h = w * .55;
        return rot(`<path d="M${x} ${y}c0-${h * 1.25} ${w}-${h * 1.25} ${w} 0z" fill="#e8b65a"/>
          <path d="M${x + w * .3} ${y - h * .1}v-${h * .55}M${x + w * .5} ${y - h * .1}v-${h * .7}M${x + w * .7} ${y - h * .1}v-${h * .55}" stroke="#d29b3e" stroke-width="${w * .04}" stroke-linecap="round"/>
          <rect x="${x - w * .04}" y="${y - h * .18}" width="${w * 1.08}" height="${h * .36}" rx="${h * .18}" fill="#f4cf82"/>
          <circle cx="${cx}" cy="${y - h * .98}" r="${w * .12}" fill="#fff4dc"/>`);
      }
      case 'beret': {
        if (an.noHat) return '';
        const w = hw * .56, y = top + hw * .05;
        return rot(`<g transform="rotate(-12 ${cx} ${y})"><ellipse cx="${cx + w * .08}" cy="${y}" rx="${w / 2}" ry="${w * .2}" fill="#e2585f"/>
          <path d="M${cx - w * .3} ${y - w * .05}q${w * .2}-${w * .12} ${w * .45}-${w * .1}" stroke="#f08a8f" stroke-width="${w * .05}" stroke-linecap="round" fill="none"/>
          <path d="M${cx + w * .08} ${y - w * .19}l${w * .02}-${w * .1}" stroke="#c94850" stroke-width="${w * .06}" stroke-linecap="round"/></g>`);
      }
      case 'crown': {
        if (an.noHat) return '';
        const w = hw * .34, x = cx - w / 2, y = top + hw * .06, h = w * .62;
        return rot(`<path d="M${x} ${y}l-${w * .04}-${h}l${w * .3} ${h * .45}l${w * .24}-${h * .7}l${w * .24} ${h * .7}l${w * .3}-${h * .45}l-${w * .04} ${h}z" fill="#ffc94a" stroke="#e0a42c" stroke-width="${w * .04}" stroke-linejoin="round"/>
          <circle cx="${cx}" cy="${y - h * .3}" r="${w * .07}" fill="#f37b8b"/><circle cx="${x + w * .18}" cy="${y - h * .25}" r="${w * .05}" fill="#8fc6dc"/><circle cx="${x + w * .82}" cy="${y - h * .25}" r="${w * .05}" fill="#8fc6dc"/>`);
      }
      case 'headphones': {
        if (an.noHat) return '';
        const l = cx - hw * .47, r = cx + hw * .47, y = Math.max(ey, top + hw * .35), cw = hw * .14, ch = hw * .26;
        return rot(`<path d="M${l + cw * .3} ${y}C${l} ${top - hw * .14} ${r} ${top - hw * .14} ${r - cw * .3} ${y}" stroke="#5b4542" stroke-width="${hw * .055}" fill="none" stroke-linecap="round"/>
          <rect x="${l - cw / 2}" y="${y - ch / 2}" width="${cw}" height="${ch}" rx="${cw / 2}" fill="#f2a7b5"/><rect x="${r - cw / 2}" y="${y - ch / 2}" width="${cw}" height="${ch}" rx="${cw / 2}" fill="#f2a7b5"/>
          <rect x="${l - cw * .18}" y="${y - ch * .3}" width="${cw * .36}" height="${ch * .6}" rx="${cw * .18}" fill="#ffd6de"/><rect x="${r - cw * .18}" y="${y - ch * .3}" width="${cw * .36}" height="${ch * .6}" rx="${cw * .18}" fill="#ffd6de"/>`);
      }
    }
    return '';
  };

  // little preview swatch for accessory pickers (drawn on a neutral head anchor)
  A.accPreview = function (kind) {
    const an = { cx: .5, top: .3, hw: .9, ex1: .36, ex2: .64, ey: .62, tilt: 0 };
    const head = `<ellipse cx="50" cy="66" rx="36" ry="28" fill="#ef7a3f"/><ellipse cx="50" cy="74" rx="20" ry="14" fill="#fff1e2"/><circle cx="36" cy="62" r="4.5" fill="#4a2a24"/><circle cx="64" cy="62" r="4.5" fill="#4a2a24"/>`;
    return `<svg viewBox="0 0 100 100">${kind === 'none' ? head : head + A.accessory(kind, an, 100, 100)}</svg>`;
  };

  // confetti shapes for celebrations
  A.confetti = ['star', 'heart', 'dot', 'sparkle'];

  window.MomoArt = A;
})();
