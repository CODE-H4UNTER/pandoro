/* Look (themes + backdrop), the popup dock, and every side panel:
   Tasks (goals + tasks), Sounds, Avatar, Look, Stats, Rewards, Settings. */
(function () {
  const St = window.MomoStore, Art = window.MomoArt, I = window.MOMO_ICONS, G = Art.glyph;
  const $ = (s, r = document) => r.querySelector(s);
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const st = () => St.state;

  // ================= theming =================
  const hexToHsl = (hex) => {
    const n = parseInt(hex.slice(1), 16), r = (n >> 16 & 255) / 255, g = (n >> 8 & 255) / 255, b = (n & 255) / 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2; let h = 0, s = 0;
    if (mx !== mn) { const d = mx - mn; s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60; }
    return [h, s * 100, l * 100];
  };
  const hsl = (h, s, l) => `hsl(${h.toFixed(0)} ${s.toFixed(0)}% ${l.toFixed(0)}%)`;
  const lum = (hex) => { const n = parseInt(hex.slice(1), 16); const c = [n >> 16 & 255, n >> 8 & 255, n & 255].map((v) => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }); return .2126 * c[0] + .7152 * c[1] + .0722 * c[2]; };
  function derivedDark(t) {
    const [h, s, al] = hexToHsl(t.accent), [ph, ps] = hexToHsl(t.pop);
    return { bg: hsl(h, Math.min(s, 18), 12), paper: hsl(h, Math.min(s, 16), 17), ink: hsl(h, 30, 92), soft: hsl(h, 14, 68), line: hsl(h, 14, 27), accent: hsl(h, Math.min(s, 62), Math.max(al, 66)), pop: hsl(ph, Math.min(ps, 30), 34) };
  }
  // warm brown kraft paper: dim, cosy, dark pencil lines
  function derivedKraft(t) {
    const [h, s] = hexToHsl(t.accent), [ph, ps] = hexToHsl(t.pop);
    return { bg: 'hsl(26 22% 15%)', paper: 'hsl(32 33% 46%)', ink: 'hsl(24 40% 11%)', soft: 'hsl(26 32% 22%)', line: 'hsl(30 28% 36%)', accent: hsl(h, Math.min(s, 55), 60), pop: hsl(ph, Math.min(ps, 35), 62) };
  }
  // which paper we're painting on: dark (night), kraft or light (cream)
  function paper() { const m = st().look.mode; return m === 'auto' ? (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light') : (m === 'light' ? 'light' : 'dark'); }
  function isDark() { return paper() !== 'light'; }
  const paletteFor = (t) => (paper() === 'dark' ? (t.dark || derivedDark(t)) : t);
  function palette() {
    const L = st().look, t = St.THEMES[St.unlocked('theme', L.theme) ? L.theme : 'lavender'];
    const p = { ...paletteFor(t) };
    if (L.accent) p.accent = L.accent;
    return p;
  }
  function bgImage(kind, line) {
    const enc = (svg) => `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
    if (kind === 'clouds') return enc(`<svg xmlns="http://www.w3.org/2000/svg" width="220" height="160"><g fill="${line}" opacity=".55"><path d="M40 60a12 12 0 0 1 2-24 16 16 0 0 1 30-2 11 11 0 0 1 10 11 7 7 0 0 1-2 15z"/><path d="M150 140a9 9 0 0 1 1-18 12 12 0 0 1 22-1 8 8 0 0 1 8 8 5 5 0 0 1-2 11z"/></g></svg>`);
    if (kind === 'stars') return enc(`<svg xmlns="http://www.w3.org/2000/svg" width="140" height="140"><g fill="${line}"><path d="M30 18l3 7 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z"/><path d="M100 80c1 6 3 8 9 9-6 1-8 3-9 9-1-6-3-8-9-9 6-1 8-3 9-9z"/><circle cx="70" cy="40" r="2"/><circle cx="20" cy="110" r="2.5"/></g></svg>`);
    if (kind === 'hearts') return enc(`<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120"><g fill="${line}"><path d="M30 42s-12-7-12-16a6.5 6.5 0 0 1 12-3.5A6.5 6.5 0 0 1 42 26c0 9-12 16-12 16z"/><path d="M90 102s-8-5-8-11a4.5 4.5 0 0 1 8-2.5 4.5 4.5 0 0 1 8 2.5c0 6-8 11-8 11z"/></g></svg>`);
    return 'none';
  }
  // ---- illustrated scene with crossfade + drifting particles ----
  let sceneShown = null, sceneFlip = 0;
  function setScene(id) {
    if (sceneShown === id) return;
    sceneShown = id;
    const layers = document.querySelectorAll('#scene .scene-layer'), next = layers[sceneFlip = 1 - sceneFlip], prev = layers[1 - sceneFlip];
    const im = new Image();
    im.onload = () => { if (sceneShown !== id) return; next.style.backgroundImage = `url(scenes/${id}.webp)`; next.classList.add('on'); prev.classList.remove('on'); };
    im.src = `scenes/${id}.webp`;
    particles(St.SCENES[id].fx);
  }
  function particles(kind) {
    const host = $('#particles'); host.dataset.fx = kind || '';
    if (!kind) { host.innerHTML = ''; return; }
    const n = kind === 'stars' ? 14 : 9;
    let html = '';
    for (let i = 0; i < n; i++) {
      const x = (i * 37 + 11) % 100, y = (i * 53 + 7) % 90, s = 0.6 + ((i * 29) % 10) / 10, d = 10 + (i * 7) % 12;
      html += `<i style="left:${x}%;top:${y}%;--s:${s};--d:${d}s;--del:${-(i * 3.1) % d}s"></i>`;
    }
    host.innerHTML = html;
  }
  function applyLook() {
    const p = palette(), r = document.documentElement.style, L = st().look;
    ['bg', 'paper', 'ink', 'soft', 'line', 'accent', 'pop'].forEach((k) => r.setProperty('--' + k, p[k]));
    r.setProperty('--accent-ink', lum(toHex(p.accent)) > .45 ? '#33242a' : '#ffffff');
    document.documentElement.dataset.dark = isDark() ? '1' : '0';
    document.documentElement.dataset.paper = paper();
    const bg = St.unlocked('bg', L.bg) ? L.bg : 'plain';
    document.body.dataset.bg = bg;
    r.setProperty('--bg-img', bgImage(bg, p.line));
    r.setProperty('--dim', L.dim);
    const sceneOn = L.backdrop === 'scene' && St.SCENES[L.scene];
    document.body.dataset.backdrop = sceneOn ? 'scene' : 'pattern';
    if (sceneOn) setScene(L.scene); else { sceneShown = null; document.querySelectorAll('#scene .scene-layer').forEach((l) => l.classList.remove('on')); particles(null); }
    $('meta[name="theme-color"]').setAttribute('content', toHex(p.bg));
  }
  const cv = document.createElement('canvas').getContext('2d');
  function toHex(c) { cv.fillStyle = '#000'; cv.fillStyle = c; const v = cv.fillStyle; if (v.startsWith('#')) return v; const m = v.match(/\d+/g); return '#' + m.slice(0, 3).map((x) => (+x).toString(16).padStart(2, '0')).join(''); }
  matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyLook);

  function applyCursor() {
    const c = Art.cursors[st().settings.cursor] || Art.cursors.strawberry, r = document.documentElement.style;
    r.setProperty('--cur', c.base === 'auto' ? 'auto' : c.base + ', auto');
    r.setProperty('--cur-ptr', c.ptr === 'pointer' ? 'pointer' : c.ptr + ', pointer');
  }

  // ================= dock =================
  const DOCK = [
    { id: 'today', label: 'Tasks', icon: `<img src="${I.sprout}" alt="">` },
    { id: 'sounds', label: 'Sounds', icon: Art.headphonesIcon },
    { id: 'momo', label: 'Avatar', icon: `<img src="sprites/h_smile.webp" alt="">` },
    { id: 'look', label: 'Look', icon: `<img src="${I.palette}" alt="">` },
    { id: 'stats', label: 'Stats', icon: `<img src="${I.stats}" alt="">` },
    { id: 'rewards', label: 'Rewards', icon: `<img src="${I.star}" alt="">` },
    { id: 'ultra', label: 'Ultra', icon: `<span class="dock-glyph">${G.target}</span>` },
    { id: 'sleep', label: 'Sleep', icon: `<img src="${I.moon}" alt="">` },
  ];
  const TITLES = { today: 'Today', sounds: 'Focus sounds', momo: 'Your panda', look: 'Look & feel', stats: 'Your progress', rewards: 'Collection', settings: 'Timer & settings' };

  // ================= panel framework =================
  let current = null;
  const ui = { goalsEdit: false, editTask: null, statsRange: 'week', confirmReset: false, newPri: '', newEst: 1, justAdded: null, showDone: true };
  const P = {};
  const Panels = {
    ui, applyLook, applyCursor, esc,
    get current() { return current; },
    init() {
      $('#dock').innerHTML = DOCK.map((d, i) => `<button class="dock-btn" data-panel="${d.id}" style="--i:${i}"><span class="dock-ico">${d.icon}</span><span class="dock-l">${d.label}</span></button>`).join('');
      $('#dock').addEventListener('click', (e) => {
        const b = e.target.closest('[data-panel]'); if (!b) return;
        const id = b.dataset.panel;
        window.MomoApp.closeDock();
        if (id === 'sleep') { window.MomoApp.setSleep(true); return; }
        if (id === 'ultra') { window.MomoApp.setUltra(true); return; }
        current === id ? this.close() : this.open(id);
      });
      $('#panelClose').innerHTML = G.close;
      $('#panelClose').addEventListener('click', () => this.close());
      $('#scrim').addEventListener('click', () => this.close());
      const body = $('#panelBody');
      ['click', 'input', 'change', 'keydown', 'submit'].forEach((type) => body.addEventListener(type, (e) => {
        const el = e.target.closest('[data-act]'); if (!el) return;
        const on = (el.dataset.on || 'click').split(' ');
        if (!on.includes(type)) return;
        if (type === 'submit') e.preventDefault();
        const fn = ACT[el.dataset.act]; if (fn) fn(el, e);
      }));
      body.addEventListener('input', (e) => { if (e.target.id === 'newTask') e.target.closest('form').classList.toggle('has-text', !!e.target.value.trim()); });
      St.on((topic) => { if (current && (topic !== 'timer' || current === 'today' || current === 'settings')) this.refresh(); });
      applyLook(); applyCursor();
    },
    open(id) {
      current = id;
      document.body.classList.remove('idle');
      document.body.classList.add('panel-open');
      $('#panel').setAttribute('aria-hidden', 'false');
      $('#panel').dataset.panel = id;
      document.querySelectorAll('.dock-btn').forEach((b) => b.classList.toggle('on', b.dataset.panel === id));
      $('#panelTitle').textContent = TITLES[id];
      this.refresh(true);
      $('#panelBody').scrollTop = 0;
    },
    close() {
      current = null; ui.editTask = null; ui.confirmReset = false;
      document.body.classList.remove('panel-open');
      $('#panel').setAttribute('aria-hidden', 'true');
      document.querySelectorAll('.dock-btn').forEach((b) => b.classList.remove('on'));
    },
    refresh(force) {
      if (!current) return;
      const body = $('#panelBody'), a = document.activeElement;
      // don't blow away an input the user is typing into
      if (!force && a && body.contains(a) && ((a.tagName === 'INPUT' && !['checkbox', 'range', 'color'].includes(a.type)) || a.tagName === 'TEXTAREA')) return;
      const keep = body.scrollTop;
      body.innerHTML = P[current]();
      body.scrollTop = keep;
      if (current === 'momo') renderPreview();
      if (ui.justAdded) setTimeout(() => { ui.justAdded = null; }, 50);
    },
  };

  // ---------- small builders ----------
  const lockBadge = (kind, id) => { const a = window.MomoRewards.unlockedBy(kind, id); return `<span class="lock" title="Unlock with “${a ? a.title : ''}”">${G.lock}</span>`; };
  const toggle = (act, on, label, hint = '') => `<label class="row toggle"><span><b>${label}</b>${hint ? `<small>${hint}</small>` : ''}</span><input type="checkbox" data-act="${act}" data-on="change" ${on ? 'checked' : ''}><i class="switch"></i></label>`;
  const seg = (act, value, opts) => `<div class="seg">${opts.map(([v, l]) => `<button type="button" class="${String(v) === String(value) ? 'on' : ''}" data-act="${act}" data-v="${v}">${l}</button>`).join('')}</div>`;
  const stepper = (act, v, min, max, step = 1, unit = '', extra = '') => `<div class="stepper"><button type="button" data-act="${act}" ${extra} data-d="-${step}" aria-label="less">${G.minus}</button><input type="number" inputmode="numeric" value="${v}" min="${min}" max="${max}" step="${step}" data-act="${act}" ${extra} data-on="change"><span class="unit">${unit}</span><button type="button" data-act="${act}" ${extra} data-d="${step}" aria-label="more">${G.plus}</button></div>`;
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const stepVal = (el, cur, min, max) => { const d = el.dataset.d ? +el.dataset.d : null; return clamp(d !== null ? cur + d : (parseInt(el.value, 10) || cur), min, max); };
  const setStepper = (el, v) => { const inp = el.closest('.stepper').querySelector('input'); inp.value = v; inp.parentElement.classList.remove('bump'); void inp.offsetWidth; inp.parentElement.classList.add('bump'); };

  // ================= TASKS / TODAY =================
  const PRI = [['', 'None'], ['low', 'Low'], ['mid', 'Medium'], ['high', 'High']];
  const priPick = (act, cur) => `<div class="pri-pick" role="radiogroup" aria-label="Priority">${PRI.map(([v, l]) => `<button type="button" class="pp ${v || 'none'}${cur === v ? ' on' : ''}" data-act="${act}" data-v="${v}" title="${l} priority" aria-label="${l} priority"><i></i></button>`).join('')}</div>`;
  const checkSVG = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.5 12.5l3.8 3.8 7.4-8.3" pathLength="1"/></svg>`;
  function taskRow(t, sel) {
    if (ui.editTask === t.id) {
      return `<form class="task editing" data-act="saveTask" data-on="submit" data-id="${t.id}">
        <input class="txt" name="title" value="${esc(t.title)}" maxlength="120" aria-label="Task name" autocomplete="off">
        <div class="opts-row"><span class="lbl">Pomodoros</span>${stepper('editEst', t.est, 1, 20)}${priPick('editPri', t.pri || '')}</div>
        <div class="task-btns"><button type="button" class="pill-btn ghost sm" data-act="cancelEdit">Cancel</button><button class="pill-btn sm">Save</button></div></form>`;
    }
    const done = t.done || 0, est = t.est || 1;
    return `<div class="task${t.completed ? ' done' : ''}${sel ? ' selected' : ''}${ui.justAdded === t.id ? ' entering' : ''}${t.pri ? ' p-' + t.pri : ''}" data-id="${t.id}">
      <button class="check" data-act="toggleTask" data-id="${t.id}" aria-label="${t.completed ? 'Mark as not done' : 'Mark as done'}">${checkSVG}</button>
      <div class="task-main" data-act="selectTask" data-id="${t.id}" title="${t.completed ? '' : sel ? 'Stop focusing on this' : 'Focus on this task'}">
        <span class="task-title"><span class="tt">${esc(t.title)}</span></span>
        <span class="task-meta"><span class="pomos"><img src="${I.tomato}" alt="">${done}/${est}</span>${sel && !t.completed ? '<span class="focus-tag">focusing</span>' : ''}${t.parked && !t.completed ? '<span class="park-tag">parked</span>' : ''}</span>
      </div>
      <div class="task-actions"><button class="icon-btn" data-act="editTask" data-id="${t.id}" aria-label="Edit">${G.edit}</button><button class="icon-btn" data-act="delTask" data-id="${t.id}" aria-label="Delete">${G.trash}</button></div>
    </div>`;
  }
  // how long the task list will take, and when you'd be done (sessions + the breaks between them)
  function planHTML() {
    const S = st(), s = S.settings, t = S.timer, T = window.MomoTimer;
    const left = S.tasks.filter((x) => !x.completed).reduce((n, x) => n + Math.max(0, (x.est || 1) - (x.done || 0)), 0);
    if (!left) return '';
    const brk = (c) => (c % s.interval === 0 ? s.long : s.short) * 60000;
    let ms = T.remaining(), c = t.cycle || 0, n = left;
    if (t.mode === 'focus') { n--; c++; while (n > 0) { ms += brk(c) + s.focus * 60000; c++; n--; } }
    else { while (n > 0) { ms += s.focus * 60000; c++; n--; if (n > 0) ms += brk(c); } }
    const at = new Date(Date.now() + ms).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    return `<div class="plan"><span><b>${left}</b> pomodoro${left === 1 ? '' : 's'} to go</span><span>about <b>${window.MomoStats.fmtMin(Math.round(ms / 60000))}</b></span><span>done around <b>${at}</b></span></div>`;
  }
  P.today = () => {
    const S = st(), R = window.MomoRewards, prog = R.goalProgress(), g = S.goals, today = St.dayKey();
    let goals;
    if (ui.goalsEdit) {
      goals = Object.keys(R.GOALS).map((k) => { const d = R.GOALS[k]; return `<div class="goal-edit"><label class="chk"><input type="checkbox" data-act="goalOn" data-on="change" data-id="${k}" ${g[k].on ? 'checked' : ''}><i></i>${d.label}</label>${stepper('goalTarget', g[k].target, d.min, d.max, d.step || 1, d.unit, `data-id="${k}"`)}</div>`; }).join('')
        + '<p class="muted small">Goals are gentle nudges. Missing one never costs you anything.</p>';
    } else if (!prog.length) {
      goals = `<p class="muted small">No goals set, and that's perfectly fine.</p>`;
    } else {
      goals = prog.map((p) => {
        if (p.id === 'days') {
          const ws = St.weekStart(), map = {}; S.history.forEach((h) => { map[St.dayKey(h.end)] = 1; });
          const dots = Array.from({ length: 7 }, (_, i) => { const k = St.dayKey(St.addDays(ws, i)); return `<i class="${map[k] ? 'on' : ''}${k === today ? ' now' : ''}" title="${'Mon Tue Wed Thu Fri Sat Sun'.split(' ')[i]}"></i>`; }).join('');
          return `<div class="goal${p.done ? ' done' : ''}"><span class="g-l">${p.label}</span><span class="week-dots">${dots}</span><b>${p.value}/${p.target}</b></div>`;
        }
        const pct = Math.min(100, Math.round(p.value / p.target * 100));
        const val = p.id === 'minutes' ? `${window.MomoStats.fmtMin(p.value)}/${window.MomoStats.fmtMin(p.target)}` : `${p.value}/${p.target}`;
        return `<div class="goal${p.done ? ' done' : ''}"><span class="g-l">${p.label}</span><span class="bar-track"><i style="--p:${pct}%"></i></span><b>${val}</b></div>`;
      }).join('');
    }
    const order = { high: 3, mid: 2, low: 1, '': 0 };
    const active = S.tasks.filter((t) => !t.completed).sort((a, b) => (order[b.pri || ''] - order[a.pri || '']) || (a.createdAt - b.createdAt));
    const doneToday = S.tasks.filter((t) => t.completed && t.completedAt && St.dayKey(t.completedAt) === today).sort((a, b) => b.completedAt - a.completedAt);
    const sel = S.timer.taskId;
    return `
      <section class="goals-card">
        <div class="block-head"><h3>Goals</h3><button class="link" data-act="goalsEdit">${ui.goalsEdit ? 'Done' : 'Edit'}</button></div>
        ${goals}
      </section>
      <form class="add-task${ui.newEst > 1 || ui.newPri ? ' has-text' : ''}" data-act="addTask" data-on="submit">
        <div class="add-row"><input class="txt" id="newTask" placeholder="Add a task..." maxlength="120" autocomplete="off" aria-label="New task"><button class="add-btn" aria-label="Add task">${G.plus}</button></div>
        <div class="add-opts"><div class="opts-row"><span class="lbl">Pomodoros</span>${stepper('newEst', ui.newEst, 1, 20)}${priPick('newPri', ui.newPri)}</div></div>
      </form>
      ${planHTML()}
      <div class="tasks">${active.map((t) => taskRow(t, sel === t.id)).join('') || (doneToday.length ? '' : `<div class="empty small"><img src="${window.MomoPanda.spriteThumb('writing')}" alt=""><p class="muted">Nothing here yet. Add one small thing to start.</p></div>`)}</div>
      ${active.length ? '<p class="hint">Tap a task to work on it next. It shows under the timer, and every session you finish is counted on it.</p>' : ''}
      ${doneToday.length ? `<button class="done-head" data-act="toggleDone" aria-expanded="${ui.showDone}">${G.chevron}<span>Done today</span><b>${doneToday.length}</b></button>
        <div class="tasks done-list${ui.showDone ? '' : ' hidden'}">${doneToday.map((t) => taskRow(t, false)).join('')}</div>` : ''}
      ${S.tasks.some((t) => t.completed) ? '<button class="link clear" data-act="clearDone">Clear finished tasks</button>' : ''}`;
  };

  // ================= SOUNDS =================
  P.sounds = () => {
    const A = window.MomoAudio, amb = st().ambient;
    const tiles = A.SOUNDS.map((s) => {
      const on = A.isPlaying(s.id), v = amb.vol[s.id] ?? 0.5;
      return `<div class="sound${on ? ' on' : ''}"><button class="sound-btn" data-act="sound" data-id="${s.id}" aria-pressed="${on}"><span class="sound-ico">${Art.sound[s.icon || s.id]}</span><span>${s.label}</span></button>
        <input type="range" min="0" max="1" step="0.01" value="${v}" data-act="soundVol" data-on="input" data-id="${s.id}" aria-label="${s.label} volume" ${on ? '' : 'tabindex="-1"'}></div>`;
    }).join('');
    return `<p class="muted small">Optional. Mix as many as you like; they keep playing through sessions and sleep mode.</p>
      <label class="row"><span><b>Volume</b></span><input type="range" class="wide" min="0" max="1" step="0.01" value="${amb.master}" data-act="master" data-on="input" aria-label="Master volume"></label>
      <div class="sounds">${tiles}</div>
      ${A.anyPlaying() ? '<button class="pill-btn ghost center" data-act="stopSounds">Stop all sounds</button>' : ''}
      ${toggle('stopAmbient', st().settings.stopAmbientOnEnd, 'Stop sounds when a session ends')}`;
  };

  // ================= AVATAR =================
  function renderPreview() {
    const host = $('#avPreview'); if (!host) return;
    const o = St.OUTFITS[st().avatar.outfit] || St.OUTFITS.red;
    host.innerHTML = `<img class="pv-img" src="sprites/${o.sprite}.webp" alt="">`;
  }
  const choiceGrid = (kind, cat, cur, render) => `<div class="choices ${kind}">${Object.keys(cat).map((id) => {
    const ok = St.unlocked(kind, id);
    return `<button class="choice${cur === id ? ' on' : ''}${ok ? '' : ' locked'}" data-act="avatar" data-kind="${kind}" data-id="${id}" ${ok ? '' : 'aria-disabled="true"'} title="${cat[id].label}">${render(id)}<span>${cat[id].label}</span>${ok ? '' : lockBadge(kind, id)}</button>`;
  }).join('')}</div>`;
  P.momo = () => {
    const av = st().avatar;
    return `<div class="av-top"><div id="avPreview" class="av-preview"></div>
        <label class="name-field"><span class="lbl">Name</span><input class="txt" data-act="name" data-on="input" maxlength="16" value="${esc(st().settings.name)}" aria-label="Panda name"></label></div>
      <h3 class="sub">Where should ${esc(st().settings.name)} be?</h3>
      ${seg('place', av.place, [['top', 'On the timer'], ['side', 'Small, at the side'], ['off', 'Hidden']])}
      <p class="muted small">${av.place === 'off' ? "Hidden for now. You'll still get the occasional cheer as a little note." : `${esc(st().settings.name)} asks how each session went, leads your breaks and cheers you on now and then.`}</p>
      <h3 class="sub">Outfit</h3>
      <p class="muted small">What ${esc(st().settings.name)} wears while resting. While you work, the activity poses keep their own clothes. More outfits unlock with achievements.</p>
      ${choiceGrid('outfit', St.OUTFITS, av.outfit, (id) => `<img src="sprites/${St.OUTFITS[id].sprite}.webp" alt="" loading="lazy">`)}`;
  };

  // ================= LOOK =================
  P.look = () => {
    const L = st().look, p = palette();
    const scenes = Object.keys(St.SCENES).map((id) => `<button class="scene-c${L.backdrop === 'scene' && L.scene === id ? ' on' : ''}" data-act="scene" data-id="${id}" style="background-image:url(scenes/${id}-thumb.webp)"><span>${St.SCENES[id].label}</span></button>`).join('');
    const bgs = Object.keys(St.BACKGROUNDS).map((id) => { const ok = St.unlocked('bg', id); return `<button class="bgc${L.backdrop !== 'scene' && L.bg === id ? ' on' : ''}${ok ? '' : ' locked'}" data-act="bg" data-id="${id}" data-bg="${id}" style="--bg-img:${bgImage(id, p.line)}"><span>${St.BACKGROUNDS[id].label}</span>${ok ? '' : lockBadge('bg', id)}</button>`; }).join('');
    const themes = Object.keys(St.THEMES).map((id) => {
      const t = St.THEMES[id], ok = St.unlocked('theme', id), d = paletteFor(t);
      return `<button class="theme${L.theme === id ? ' on' : ''}${ok ? '' : ' locked'}" data-act="theme" data-id="${id}" style="--tb:${d.bg};--tp:${d.paper};--ta:${d.accent}" title="${t.label}"><span class="th-dot"><i></i></span><span class="th-name">${t.label}</span>${ok ? '' : lockBadge('theme', id)}</button>`;
    }).join('');
    const curs = St.CURSORS.map((id) => { const c = Art.cursors[id]; return `<button class="cursor-c${st().settings.cursor === id ? ' on' : ''}" data-act="cursor" data-id="${id}" title="${c.label}">${c.svg ? c.svg.replace('width="32" height="32"', 'width="30" height="30"') : '<span class="sys">Aa</span>'}<span>${c.label}</span></button>`; }).join('');
    const favs = L.favs.map((f, i) => { const t = St.THEMES[f.theme] || St.THEMES.lavender; return `<div class="fav"><button class="fav-btn" data-act="applyFav" data-i="${i}" style="--a:${f.accent || t.accent};--b:${f.backdrop === 'scene' ? 'center/cover url(scenes/' + f.scene + '-thumb.webp)' : t.bg}" title="${esc(f.name)}"><i></i></button><span>${esc(f.name)}</span><button class="icon-btn tiny" data-act="delFav" data-i="${i}" aria-label="Remove ${esc(f.name)}">${G.close}</button></div>`; }).join('');
    return `<h3 class="sub first">Scene</h3><div class="scenes">${scenes}</div>
      ${L.backdrop === 'scene' ? `<label class="row"><span><b>Dim the scene</b><small>darker is calmer</small></span><input type="range" class="wide" min="0" max="0.7" step="0.01" value="${L.dim}" data-act="dim" data-on="input" aria-label="Dim the scene"></label>` : ''}
      <h3 class="sub">Or keep it simple</h3><div class="bgs">${bgs}</div>
      <h3 class="sub">Colours</h3><div class="themes">${themes}</div>
      <div class="row"><span><b>Mode</b></span>${seg('mode', L.mode === 'kraft' ? 'dark' : L.mode, [['dark', 'Dark'], ['light', 'Light'], ['auto', 'Auto']])}</div>
      <div class="row"><span><b>Accent</b></span><div class="accent-row"><input type="color" value="${toHex(p.accent)}" data-act="accent" data-on="input" aria-label="Accent colour">
        ${['#ef8a55', '#e8707a', '#df8ea6', '#9784cf', '#5b8fc7', '#5fb39a', '#87a463', '#dea232'].map((c) => `<button class="dot-c" style="--c:${c}" data-act="accentPick" data-v="${c}" aria-label="Accent ${c}"></button>`).join('')}</div></div>
      ${L.accent ? '<button class="link" data-act="accentReset">Use the theme accent</button>' : ''}
      <h3 class="sub">Cursor</h3><div class="cursors">${curs}</div>
      <h3 class="sub">Saved looks</h3>
      <div class="favs">${favs || '<p class="muted small">Save combinations you love to switch back anytime.</p>'}</div>
      <button class="pill-btn ghost sm" data-act="saveFav">${G.heart}<span>Save this look</span></button>`;
  };

  // ================= STATS / REWARDS =================
  // the little journal from check-ins: what each session was for and how it went
  function notesHTML() {
    const recs = st().history.filter((h) => h.completed).slice(-8).reverse();
    if (!recs.length) return '';
    const D = window.MomoDoodle;
    const water = st().coach.day === St.dayKey() ? st().coach.water : 0;
    return `<h3 class="sub">Session notes</h3><div class="notes">${recs.map((h) => `<div class="note">
        <span class="note-face">${h.rating ? D.FACES[h.rating] : '<i class="no-face"></i>'}</span>
        <span class="note-main"><b>${h.intent ? esc(h.intent) : '<span class="muted">no note</span>'}</b>
        <small>${new Date(h.end).toLocaleDateString(undefined, { weekday: 'short' })} ${new Date(h.end).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })} · ${h.min} min${h.slips ? ` · wandered off ${h.slips === 1 ? 'once' : h.slips + 'x'}` : ''}</small></span></div>`).join('')}</div>
      ${water ? `<p class="muted small">Water breaks today: ${water}</p>` : ''}`;
  }
  P.stats = () => `${seg('range', ui.statsRange, [['day', 'Day'], ['week', 'Week'], ['month', 'Month']])}<div class="stats">${window.MomoStats.render(ui.statsRange)}${notesHTML()}</div>`;
  P.rewards = () => {
    const L = window.MomoRewards.LIST, got = st().achievements, n = L.filter((a) => got[a.id]).length;
    return `      <p class="muted small">${n} of ${L.length} collected. Each one unlocks something cute for ${esc(st().settings.name)}. No rush, they'll wait for you.</p>
      <div class="badges">${L.map((a) => `<div class="badge${got[a.id] ? ' got' : ''}">
        <span class="badge-art"><img src="${window.MomoPanda.spriteThumb(a.pose)}" alt=""></span>
        <div><b>${a.title}</b><p>${a.desc}</p><small>${got[a.id] ? 'Unlocked ' + new Date(got[a.id]).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ' · ' : 'Unlocks '}${a.rewards.map(window.MomoRewards.rewardLabel).join(', ')}</small></div>
        ${got[a.id] ? '' : `<span class="lock">${G.lock}</span>`}</div>`).join('')}</div>`;
  };

  // ================= SETTINGS =================
  P.settings = () => {
    const s = st().settings, A = window.MomoAudio, running = st().timer.status !== 'idle';
    const notifState = !('Notification' in window) ? 'Not supported in this browser' : Notification.permission === 'denied' ? 'Blocked in browser settings' : '';
    const dur = (k, min, max, unit) => `<div class="row"><span><b>${{ focus: 'Focus', short: 'Short break', long: 'Long break', interval: 'Long break every' }[k]}</b></span>${stepper('dur', s[k], min, max, 1, unit, `data-k="${k}"`)}</div>`;
    return `<h3 class="sub first">Preset</h3>
      <div class="presets">${Object.keys(St.PRESETS).map((k) => `<button class="preset${s.preset === k ? ' on' : ''}" data-act="preset" data-v="${k}"><b>${St.PRESETS[k].label}</b><small>${k === 'custom' ? `${s.focus} / ${s.short}` : St.PRESETS[k].sub}</small></button>`).join('')}</div>
      ${running ? '<p class="muted small">New durations apply from the next session.</p>' : ''}
      ${dur('focus', 1, 180, 'min')}${dur('short', 1, 60, 'min')}${dur('long', 1, 90, 'min')}${dur('interval', 1, 12, 'focus')}
      ${toggle('autoBreak', s.autoBreak, 'Start breaks automatically')}
      ${toggle('autoFocus', s.autoFocus, 'Start focus automatically', 'after a break ends')}
      <h3 class="sub">When a session ends</h3>
      <div class="row"><span><b>Chime</b></span><div class="inline"><select class="sel" data-act="chime" data-on="change">${Object.keys(A.CHIMES).map((k) => `<option value="${k}" ${s.chime === k ? 'selected' : ''}>${A.CHIMES[k]}</option>`).join('')}</select><button class="pill-btn ghost sm" data-act="testChime">Play</button></div></div>
      <div class="row"><span><b>Chime volume</b></span><input type="range" min="0" max="1" step="0.05" value="${s.chimeVol}" data-act="chimeVol" data-on="change"></div>
      ${toggle('notify', s.notify && !notifState, 'Desktop notification', notifState || 'a little ping even if the tab is hidden')}
      ${toggle('stopAmbient', s.stopAmbientOnEnd, 'Stop focus sounds')}
      <h3 class="sub">Calm screen</h3>
      <div class="row"><span><b>When idle, hide</b><small>move the mouse to bring it back</small></span><select class="sel" data-act="idleMode" data-on="change">
        ${[['timer', 'all but the timer'], ['all', 'all but the clock'], ['off', 'nothing']].map(([v, l]) => `<option value="${v}" ${s.idleMode === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
      <div class="row"><span><b>Idle after</b></span><select class="sel" data-act="idleDelay" data-on="change">${[3, 6, 10, 20, 45].map((v) => `<option value="${v}" ${+s.idleDelay === v ? 'selected' : ''}>${v} seconds</option>`).join('')}</select></div>
      <div class="row"><span><b>Animations</b></span>${seg('motion', s.motion, [['full', 'Lively'], ['gentle', 'Gentle']])}</div>
      ${toggle('messages', s.messages, `Cheers & messages from ${esc(s.name)}`)}
      <h3 class="sub">Your data</h3>
      <p class="muted small">Everything is saved on this device automatically. No account needed.</p>
      <div class="inline wrap"><button class="pill-btn ghost sm" data-act="export">Export backup</button>
        <label class="pill-btn ghost sm file">Import backup<input type="file" accept="application/json,.json" data-act="import" data-on="change"></label>
        <button class="pill-btn ghost sm danger" data-act="resetAll">${ui.confirmReset ? 'Tap again to erase everything' : 'Erase all data'}</button></div>
      <p class="muted small keys">Shortcuts: <kbd>Space</kbd> start / pause · <kbd>R</kbd> reset · <kbd>S</kbd> skip · <kbd>+</kbd> add a minute · <kbd>N</kbd> park a thought · <kbd>U</kbd> ultra focus · <kbd>F</kbd> full screen${'documentPictureInPicture' in window ? ' · <kbd>P</kbd> mini timer' : ''} · <kbd>M</kbd> menu · <kbd>Esc</kbd> close · <kbd>?</kbd> all shortcuts</p>`;
  };

  // ================= actions =================
  const findTask = (id) => st().tasks.find((t) => t.id === id);
  const rowOf = (id) => document.querySelector(`.task[data-id="${id}"]`);
  const collapse = (row, cb) => {
    if (!row) return cb();
    row.style.height = row.offsetHeight + 'px'; void row.offsetHeight;
    row.classList.add('leaving'); row.style.height = '0px';
    setTimeout(cb, 320);
  };
  const ACT = {
    // ---- goals ----
    goalsEdit() { ui.goalsEdit = !ui.goalsEdit; Panels.refresh(true); },
    goalOn(el) { st().goals[el.dataset.id].on = el.checked; St.save(); window.MomoApp.afterProgress(); },
    goalTarget(el) { const g = st().goals[el.dataset.id], d = window.MomoRewards.GOALS[el.dataset.id]; g.target = stepVal(el, g.target, d.min, d.max); setStepper(el, g.target); St.save(); },
    // ---- new task ----
    newEst(el) { ui.newEst = stepVal(el, ui.newEst, 1, 20); setStepper(el, ui.newEst); },
    newPri(el) { ui.newPri = el.dataset.v; el.parentElement.querySelectorAll('.pp').forEach((b) => b.classList.toggle('on', b === el)); },
    addTask() {
      const inp = $('#newTask'), title = inp.value.trim(); if (!title) { inp.focus(); return; }
      const t = { id: St.uid(), title, pri: ui.newPri || '', est: ui.newEst, done: 0, completed: false, createdAt: Date.now() };
      st().tasks.push(t);
      if (!st().timer.taskId && !st().timer.intent) { st().timer.taskId = t.id; st().timer.intent = t.title; window.MomoCoach.render(true); }
      ui.newEst = 1; ui.newPri = ''; ui.justAdded = t.id;
      St.emit('tasks'); Panels.refresh(true); $('#newTask').focus();
    },
    // ---- existing tasks ----
    toggleTask(el) {
      const t = findTask(el.dataset.id); if (!t) return;
      const finish = () => {
        t.completed = !t.completed; t.completedAt = t.completed ? Date.now() : null;
        st().meta.tasksCompleted = Math.max(0, (st().meta.tasksCompleted || 0) + (t.completed ? 1 : -1));
        if (t.completed && st().timer.taskId === t.id && st().timer.status === 'idle') { st().timer.taskId = null; if (st().timer.intent === t.title) st().timer.intent = ''; window.MomoCoach.render(true); }
        St.emit('tasks'); window.MomoApp.afterProgress();
      };
      if (t.completed) return finish();
      // satisfying tick: draw the check, strike the title, then glide into "done"
      const row = rowOf(t.id); row && row.classList.add('completing');
      window.MomoAudio.blip();
      const r = el.getBoundingClientRect(); window.MomoFX.burst(r.left + r.width / 2, r.top + r.height / 2, 10);
      window.MomoPanda.react('heart', 'taskDone', 2800, true);
      setTimeout(() => collapse(row, finish), 650);
    },
    selectTask(el) {
      const t = findTask(el.dataset.id); if (!t || t.completed) return;
      const T = st().timer;
      if (T.taskId === t.id) { T.taskId = null; if (T.intent === t.title) T.intent = ''; }
      else { T.taskId = t.id; T.intent = t.title; }
      St.emit('tasks'); window.MomoCoach.render(true);
    },
    editTask(el) { ui.editTask = el.dataset.id; Panels.refresh(true); const f = $('.task.editing .txt'); if (f) { f.focus(); f.select(); } },
    editEst(el) { const t = findTask(ui.editTask); if (!t) return; t.est = stepVal(el, t.est, 1, 20); setStepper(el, t.est); },
    editPri(el) { const t = findTask(ui.editTask); if (!t) return; t.pri = el.dataset.v; el.parentElement.querySelectorAll('.pp').forEach((b) => b.classList.toggle('on', b === el)); },
    cancelEdit() { ui.editTask = null; St.save(); Panels.refresh(true); },
    saveTask(el) {
      const t = findTask(el.dataset.id); if (!t) return;
      const title = el.querySelector('[name=title]').value.trim(); if (!title) return;
      t.title = title; ui.editTask = null; St.emit('tasks'); Panels.refresh(true);
    },
    delTask(el) {
      const id = el.dataset.id;
      collapse(rowOf(id), () => {
        const i = st().tasks.findIndex((t) => t.id === id); if (i < 0) return;
        st().tasks.splice(i, 1); if (st().timer.taskId === id) st().timer.taskId = null; St.emit('tasks');
      });
    },
    toggleDone() { ui.showDone = !ui.showDone; Panels.refresh(true); },
    clearDone() { const rows = document.querySelectorAll('.task.done'); rows.forEach((r) => collapse(r, () => {})); setTimeout(() => { st().tasks = st().tasks.filter((t) => !t.completed); St.emit('tasks'); }, 330); },
    // ---- sounds ----
    sound(el) {
      const A = window.MomoAudio, id = el.dataset.id, amb = st().ambient;
      if (A.isPlaying(id)) { A.stop(id); amb.on = amb.on.filter((x) => x !== id); }
      else { A.setMaster(amb.master); A.start(id, amb.vol[id] ?? 0.5); if (!amb.on.includes(id)) amb.on.push(id); }
      St.emit('sounds'); window.MomoPanda.refresh();
    },
    soundVol(el) { st().ambient.vol[el.dataset.id] = +el.value; window.MomoAudio.setVolume(el.dataset.id, +el.value); St.save(); },
    master(el) { st().ambient.master = +el.value; window.MomoAudio.setMaster(+el.value); St.save(); },
    stopSounds() { window.MomoAudio.stopAll(); st().ambient.on = []; St.emit('sounds'); },
    stopAmbient(el) { st().settings.stopAmbientOnEnd = el.checked; St.emit('settings'); },
    // ---- avatar ----
    avatar(el) {
      const { kind, id } = el.dataset;
      if (!St.unlocked(kind, id)) { const a = window.MomoRewards.unlockedBy(kind, id); window.MomoApp.toast(`Locked. Earn “${a.title}” to unlock: ${a.desc.toLowerCase()}.`, a.pose); return; }
      st().avatar.outfit = id;
      St.emit('avatar'); window.MomoPanda.react('outfit', null, 2600, true); // show it off for a moment
    },
    place(el) { st().avatar.place = el.dataset.v; St.emit('avatar'); window.MomoPanda.applyPlace(); },
    name(el) { st().settings.name = el.value.trim().slice(0, 16) || 'Momo'; St.save(); window.MomoApp.renderNames(); },
    // ---- look ----
    scene(el) { Object.assign(st().look, { backdrop: 'scene', scene: el.dataset.id }); applyLook(); St.emit('look'); },
    dim(el) { st().look.dim = +el.value; document.documentElement.style.setProperty('--dim', el.value); St.save(); },
    bg(el) {
      const id = el.dataset.id;
      if (!St.unlocked('bg', id)) { const a = window.MomoRewards.unlockedBy('bg', id); window.MomoApp.toast(`Earn “${a.title}” to unlock this background.`, a.pose); return; }
      Object.assign(st().look, { backdrop: 'pattern', bg: id }); applyLook(); St.emit('look');
    },
    theme(el) {
      const id = el.dataset.id;
      if (!St.unlocked('theme', id)) { const a = window.MomoRewards.unlockedBy('theme', id); window.MomoApp.toast(`Earn “${a.title}” to unlock ${St.THEMES[id].label}.`, a.pose); return; }
      st().look.theme = id; st().look.accent = null; applyLook(); St.emit('look');
    },
    mode(el) { st().look.mode = el.dataset.v; applyLook(); St.emit('look'); },
    accent(el) { st().look.accent = el.value; applyLook(); St.save(); },
    accentPick(el) { st().look.accent = el.dataset.v; applyLook(); St.emit('look'); },
    accentReset() { st().look.accent = null; applyLook(); St.emit('look'); },
    cursor(el) { st().settings.cursor = el.dataset.id; applyCursor(); St.emit('settings'); },
    saveFav() {
      const L = st().look; if (L.favs.length >= 12) L.favs.shift();
      const name = L.backdrop === 'scene' ? St.SCENES[L.scene].label : St.THEMES[L.theme].label;
      L.favs.push({ name: `${name} ${L.favs.length + 1}`, theme: L.theme, mode: L.mode, accent: L.accent, bg: L.bg, backdrop: L.backdrop, scene: L.scene, dim: L.dim }); St.emit('look');
    },
    applyFav(el) { const f = st().look.favs[+el.dataset.i]; if (!f) return; Object.assign(st().look, f, { favs: st().look.favs }); delete st().look.name; applyLook(); St.emit('look'); },
    delFav(el) { st().look.favs.splice(+el.dataset.i, 1); St.emit('look'); },
    // ---- stats ----
    range(el) { ui.statsRange = el.dataset.v; Panels.refresh(true); },
    // ---- settings ----
    preset(el) {
      const k = el.dataset.v, s = st().settings; s.preset = k;
      if (k !== 'custom') Object.assign(s, { focus: St.PRESETS[k].focus, short: St.PRESETS[k].short, long: St.PRESETS[k].long });
      St.emit('settings'); window.MomoTimer.syncDurations(); Panels.refresh(true);
    },
    dur(el) {
      const s = st().settings, k = el.dataset.k, lim = { focus: [1, 180], short: [1, 60], long: [1, 90], interval: [1, 12] }[k];
      s[k] = stepVal(el, s[k], lim[0], lim[1]); setStepper(el, s[k]);
      if (k !== 'interval') { const match = Object.keys(St.PRESETS).find((p) => p !== 'custom' && St.PRESETS[p].focus === s.focus && St.PRESETS[p].short === s.short && St.PRESETS[p].long === s.long); s.preset = match || 'custom'; }
      document.querySelectorAll('.preset').forEach((b) => b.classList.toggle('on', b.dataset.v === s.preset));
      St.save(); window.MomoTimer.syncDurations();
    },
    autoBreak(el) { st().settings.autoBreak = el.checked; St.save(); },
    autoFocus(el) { st().settings.autoFocus = el.checked; St.save(); },
    chime(el) { st().settings.chime = el.value; St.save(); window.MomoAudio.chime(el.value, st().settings.chimeVol); },
    testChime() { window.MomoAudio.chime(st().settings.chime, st().settings.chimeVol); },
    chimeVol(el) { st().settings.chimeVol = +el.value; St.save(); window.MomoAudio.chime(st().settings.chime, +el.value); },
    async notify(el) {
      const s = st().settings;
      if (el.checked && 'Notification' in window) {
        const p = Notification.permission === 'default' ? await Notification.requestPermission() : Notification.permission;
        s.notify = p === 'granted';
      } else s.notify = false;
      St.emit('settings'); Panels.refresh(true);
    },
    idleMode(el) { st().settings.idleMode = el.value; St.emit('settings'); },
    idleDelay(el) { st().settings.idleDelay = +el.value; St.emit('settings'); },
    motion(el) { st().settings.motion = el.dataset.v; document.body.dataset.motion = el.dataset.v; St.emit('settings'); },
    messages(el) { st().settings.messages = el.checked; St.save(); },
    export() {
      const blob = new Blob([St.exportJSON()], { type: 'application/json' }), a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = `pandoro-backup-${St.dayKey()}.json`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    },
    import(el) {
      const f = el.files && el.files[0]; if (!f) return;
      f.text().then((txt) => { try { St.importJSON(txt); } catch (e) { window.MomoApp.toast("That file doesn't look like a Pandoro backup.", 'curious'); } });
    },
    resetAll() { if (!ui.confirmReset) { ui.confirmReset = true; Panels.refresh(true); return; } St.reset(); },
  };

  window.MomoPanels = Panels;
})();
