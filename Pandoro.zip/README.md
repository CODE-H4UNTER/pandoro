# Pandoro: study with a red panda

A calm, minimal Pomodoro timer. A big glass timer card is the hero; your red panda sits on a little shelf above it (or small at the side, or hidden).

**Run it:** double-click `index.html`, or `python serve.py` and open http://localhost:5190. No account, everything saves on your device. Only the Fredoka font loads from the internet.

## Using it
- **Timer card:** mode chip (Focus / Short / Long), the clock, a slim progress line, Start / Reset / Skip, and a line for what this session is for (type, or pick one of your tasks).
- **Change the time:** tap the clock for −5, −1, +1, +5. Adding is instant; taking time off always asks first. Changes apply to this session only (`+` key adds a minute).
- **Ultra focus** (target button at the top, the dock, or `U`): full screen, only the clock, no messages or toasts. If you leave the tab the title flashes "Come back to focus". Move the mouse for a small Exit button, or press `Esc`. It ends by itself when the session finishes.
- **The panda:** asks how each session went (meh / okay / great, saved in Stats → Session notes), leads a small activity in every break (breathe, stretch, rest your eyes, water, walk, snack), notices when you leave the tab, and cheers you on now and then. It has 32 drawn poses (reading, laptop, music, boba, nap, peeking...), springs between them, blinks, and its hearts / notes / zzz float on their own. In sleep mode it always curls up in the middle of the screen.
- **Outfits** (Avatar panel): what the panda wears while resting: hoodies, round glasses, beanie, headphones, sunglasses, explorer hat, festive hat, nightcap, crown. They're real drawings, so nothing smears; the extra ones unlock with achievements.
- Reset, skip and switching mode ask for a second tap once more than a minute of the session would be lost.
- **Park a thought** (`N`, or the note button under the timer, works in ultra focus too): type the distraction, press Enter, keep going. It lands in your tasks marked "parked", and the panda reminds you after the session.
- **Plan:** the Tasks panel adds up the pomodoros left (with the breaks in between) and tells you roughly when you'll be done.
- **Mini timer** (`P`, Chrome / Edge): pops the clock into a small window that stays on top of everything.
- **Tab icon:** the panda inside a progress ring, so you can see the session from any tab.
- **Install it:** served over http (e.g. `python serve.py`), the browser offers "Install app", and it keeps working offline.
- `?` shows every shortcut.

## Files
- `js/timer.js`: timestamp-based timer (accurate in background tabs, survives refresh), plus per-session time changes
- `js/app.js`: timer card, time editor, dock, ultra focus, idle, sleep, leave detection
- `js/coach.js`: the line under the controls: intention, check-in, break coach
- `js/panda.js`: picks the pose, spring transitions, blinking, floating extras, the typing speech bubble
- `sprites/`: the sticker sheet cut into poses (`.webp`), eyes-closed frames (`.blink.webp`), floating extras (`.deco.webp`), faces (`h_*`) and little props (`a_*`); `js/sprites.js` lists them · `js/assets.js`: small UI icons
- `js/panels.js`: themes, scenes, dock and side panels · `js/audio.js`, `js/rewards.js`, `js/stats.js`, `js/doodles.js`
- `scenes/`: illustrated backgrounds · `serve.py`: a tiny no-cache local server

Shortcuts: `Space` start/pause · `R` reset · `S` skip · `+` add a minute · `N` park a thought · `U` ultra focus · `F` full screen · `P` mini timer · `M` menu · `Esc` close · `?` all shortcuts.

Also: `manifest.webmanifest` + `sw.js` (install + offline, network-first so updates always show), `icons/` (app icons).
