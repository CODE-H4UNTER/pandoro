/* What sits under the timer controls.
   - focus: a one-line "what's this session for?" (pick a task or just type)
   - right after focus: "how did it go?" with three faces
   - breaks: the panda leads a tiny break activity (breathe, stretch, eyes, water, walk)
 */
(function () {
  const St = window.MomoStore, D = window.MomoDoodle, I = window.MOMO_ICONS, G = window.MomoArt.glyph;
  const st = () => St.state;
  const $ = (s) => document.querySelector(s);
  const esc = (s) => window.MomoPanels.esc(s);
  const name = () => st().settings.name || 'Momo';

  // ---------- break activities ----------
  const ACTS = {
    breathe: { title: 'Breathe with {name}', pose: 'calm', modes: ['short', 'long'] },
    stretch: { title: 'A tiny stretch', pose: 'cheer', modes: ['short', 'long'],
      steps: ['Roll your shoulders back, five slow times', 'Reach both arms up, as high as you can', 'Tilt your head left... and right', 'Shake out your hands', 'Sit back down, nice and tall'] },
    eyes: { title: 'Rest your eyes', pose: 'burrito', modes: ['short', 'long'],
      steps: ['Look at something far away', 'Keep looking, about twenty seconds', 'Now blink slowly a few times', 'Close your eyes for a moment'] },
    water: { title: 'Sip some water', pose: 'boba', modes: ['short', 'long'] },
    walk: { title: 'A little walk', pose: 'run', modes: ['long'], text: "Stand up and wander around for a bit. I'll keep the time." },
    snack: { title: 'Snack time', pose: 'boba', modes: ['long'], text: 'Grab something small and tasty. Fruit counts as a treat.' },
  };
  const eligible = (mode) => Object.keys(ACTS).filter((k) => ACTS[k].modes.includes(mode));
  function pickAct(mode, avoid) {
    const list = eligible(mode).filter((k) => k !== avoid);
    const c = st().coach;
    c.pick = { id: list[Math.floor(Math.random() * list.length)], mode, since: Date.now() };
    St.save();
    return c.pick;
  }
  function currentAct() {
    const t = st().timer, c = st().coach;
    if (t.mode === 'focus') return null;
    if (!c.pick || c.pick.mode !== t.mode || !ACTS[c.pick.id]) return pickAct(t.mode);
    return c.pick;
  }
  function waterToday() { const c = st().coach; if (c.day !== St.dayKey()) { c.day = St.dayKey(); c.water = 0; } return c.water; }

  // ---------- rendering the card foot ----------
  let shownKey = '', lastMode = null, stepT = null;
  function footKey() {
    const t = st().timer, ck = st().checkin;
    if (ck) return 'checkin:' + ck.recId;
    if (t.mode === 'focus') return 'focus';
    const a = currentAct(); return `coach:${t.mode}:${a.id}:${a.since}:${a.done ? 1 : 0}`;
  }
  function render(force) {
    const t = st().timer;
    // starting a new focus session closes an unanswered check-in
    if (st().checkin && t.mode === 'focus' && t.status === 'running') { st().checkin = null; St.save(); }
    // a fresh break gets a fresh activity
    if (lastMode && lastMode === 'focus' && t.mode !== 'focus') pickAct(t.mode, st().coach.pick && st().coach.pick.id);
    lastMode = t.mode;
    const key = footKey(), foot = $('#footMain');
    fillTaskList();
    if (key === shownKey && !force) return updateLive();
    // don't rebuild while the person is typing their intention
    if (!force && document.activeElement && document.activeElement.id === 'intent' && key === 'focus') return;
    shownKey = key;
    $('#cardFoot').dataset.kind = key.split(':')[0];
    foot.innerHTML = key.startsWith('checkin') ? checkinHTML() : key === 'focus' ? intentHTML() : coachHTML();
    foot.classList.remove('swap'); void foot.offsetWidth; foot.classList.add('swap');
    updateLive();
  }

  function linkedTask() { const t = st().timer; return st().tasks.find((x) => x.id === t.taskId && !x.completed); }
  function intentHTML() {
    const task = linkedTask(), v = st().timer.intent || (task ? task.title : '');
    return `<label class="intent"><span class="intent-ico">${G.pencil}</span>
      <input id="intent" list="taskList" maxlength="80" autocomplete="off" spellcheck="false" placeholder="what's this session for?" value="${esc(v)}" aria-label="What this session is for">
      <span class="intent-n" id="intentN"></span></label>
      <button class="intent-tasks" id="parkBtn" title="Park a thought for later (N)" aria-label="Park a thought for later">${G.note}</button>
      <button class="intent-tasks" id="intentTasks" title="Your tasks" aria-label="Open your tasks">${G.list}</button>`;
  }
  function checkinHTML() {
    const ck = st().checkin;
    return `<div class="checkin">
      <p class="ck-q">How did it go?${ck.intent ? ` <span class="ck-intent">“${esc(ck.intent)}”</span>` : ''}</p>
      <div class="faces">${[['meh', 'Meh'], ['ok', 'Okay'], ['great', 'Great']].map(([k, l]) => `<button class="face" data-rate="${k}" aria-label="${l}">${D.FACES[k]}<span>${l.toLowerCase()}</span></button>`).join('')}</div>
      ${ck.slips ? `<p class="ck-note">You wandered off ${ck.slips === 1 ? 'once' : ck.slips + ' times'}. That's okay.</p>` : ''}
      <button class="link-btn" data-rate="skip">skip</button></div>`;
  }
  function coachHTML() {
    const a = currentAct(), A = ACTS[a.id], title = A.title.replace('{name}', esc(name()));
    let body = '';
    if (a.id === 'breathe') body = `<div class="breath"><span class="breath-ring"><i></i></span><span class="breath-say"><b>breathe in</b><b>hold</b><b>breathe out</b></span></div>`;
    else if (A.steps) body = `<p class="coach-step" id="coachStep"></p><div class="coach-dots" id="coachDots">${A.steps.map(() => '<i></i>').join('')}</div>`;
    else if (a.id === 'water') body = a.done ? `<p class="coach-text">Lovely. That's ${waterToday()} today.</p>` : `<button class="pill-btn sm" id="waterBtn">${G.check}<span>done, had some</span></button>`;
    else body = `<p class="coach-text">${A.text}</p>`;
    return `<div class="coach"><div class="coach-head"><span class="coach-title">${title}</span><button class="link-btn" id="coachNext">another</button></div>${body}</div>`;
  }

  // small bits that change without rebuilding
  function updateLive() {
    const n = $('#intentN');
    if (n) { const task = linkedTask(); n.innerHTML = task ? `<img src="${I.tomato}" alt="">${task.done || 0}/${task.est}` : ''; }
    const step = $('#coachStep');
    if (step) {
      const a = currentAct(), steps = ACTS[a.id].steps, i = Math.floor((Date.now() - a.since) / 12000) % steps.length;
      if (step.dataset.i !== String(i)) {
        step.dataset.i = i; step.classList.remove('in'); void step.offsetWidth; step.textContent = steps[i]; step.classList.add('in');
        document.querySelectorAll('#coachDots i').forEach((d, k) => d.classList.toggle('on', k === i));
      }
    }
  }
  function fillTaskList() {
    const list = $('#taskList'), html = st().tasks.filter((t) => !t.completed).map((t) => `<option value="${esc(t.title)}"></option>`).join('');
    if (list.innerHTML !== html) list.innerHTML = html;
  }

  // ---------- events ----------
  function onIntentInput(e) {
    const v = e.target.value, t = st().timer;
    t.intent = v.trim();
    const match = st().tasks.find((x) => !x.completed && x.title.trim().toLowerCase() === t.intent.toLowerCase());
    if (match) t.taskId = match.id;
    else if (t.taskId) { const cur = st().tasks.find((x) => x.id === t.taskId); if (!cur || cur.title.trim() !== t.intent) t.taskId = null; }
    St.save(); updateLive();
  }
  function rate(k) {
    const ck = st().checkin; if (!ck) return;
    if (k !== 'skip') {
      const rec = st().history.find((h) => h.id === ck.recId); if (rec) rec.rating = k;
      const P = window.MomoPanda;
      if (k === 'great') { P.react('cheer', 'rateGreat', 3200, true); window.MomoApp.celebrate(); }
      else if (k === 'ok') P.react('heart', 'rateOk', 3200, true);
      else P.react('heart', 'rateMeh', 3800);
    }
    st().checkin = null; St.emit('checkin');
  }

  const Coach = {
    ACTS,
    init() {
      const foot = $('#cardFoot');
      foot.addEventListener('input', (e) => { if (e.target.id === 'intent') onIntentInput(e); });
      foot.addEventListener('keydown', (e) => {
        if (e.target.id === 'intent' && e.key === 'Enter') { e.preventDefault(); e.target.blur(); if (st().timer.status !== 'running') { window.MomoAudio.unlock(); window.MomoTimer.start(); } }
      });
      foot.addEventListener('change', (e) => { if (e.target.id === 'intent') { onIntentInput(e); St.emit('tasks'); } });
      foot.addEventListener('click', (e) => {
        const r = e.target.closest('[data-rate]'); if (r) return rate(r.dataset.rate);
        if (e.target.closest('#intentTasks')) return window.MomoPanels.open('today');
        if (e.target.closest('#parkBtn')) return window.MomoApp.openPark();
        if (e.target.closest('#coachNext')) { const a = currentAct(); pickAct(st().timer.mode, a.id); render(true); window.MomoPanda.refresh(); return; }
        if (e.target.closest('#waterBtn')) {
          waterToday(); st().coach.water++; st().coach.pick.done = true; St.save();
          window.MomoPanda.react('boba', `Hydrated! That's ${st().coach.water} today.`, 3200, true);
          render(true);
        }
      });
      St.on((topic) => { render(); if (topic === 'record' || topic === 'tasks') updateLive(); });
      stepT = setInterval(updateLive, 1000);
      render(true);
    },
    render,
    pose() {
      if (st().checkin) return 'curious';
      const t = st().timer; if (t.mode === 'focus') return null;
      const a = currentAct(); return a ? ACTS[a.id].pose : null;
    },
  };
  window.MomoCoach = Coach;
})();
