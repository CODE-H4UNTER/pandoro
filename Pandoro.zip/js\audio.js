/* All sound is synthesised with the Web Audio API: completion chimes + an ambient mixer.
   No audio files needed, so the app works fully offline. */
(function () {
  let ctx = null, master = null;
  const getCtx = () => {
    if (!ctx) {
      ctx = new (window.AudioContext || window.webkitAudioContext)();
      master = ctx.createGain(); master.connect(ctx.destination);
    }
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  };

  // ---------- noise buffers ----------
  const buffers = {};
  function noise(kind) {
    if (buffers[kind]) return buffers[kind];
    const c = getCtx(), len = c.sampleRate * 6, b = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const d = b.getChannelData(ch);
      let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0, last = 0;
      for (let i = 0; i < len; i++) {
        const w = Math.random() * 2 - 1;
        if (kind === 'white') d[i] = w * 0.35;
        else if (kind === 'pink') {
          b0 = 0.99886 * b0 + w * 0.0555179; b1 = 0.99332 * b1 + w * 0.0750759; b2 = 0.969 * b2 + w * 0.153852;
          b3 = 0.8665 * b3 + w * 0.3104856; b4 = 0.55 * b4 + w * 0.5329522; b5 = -0.7616 * b5 - w * 0.016898;
          d[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362) * 0.09; b6 = w * 0.115926;
        } else { last = (last + 0.02 * w) / 1.02; d[i] = last * 3.2; }
      }
      // crossfade the loop seam
      const f = 2048; for (let i = 0; i < f; i++) { const t = i / f; d[i] = d[i] * t + d[len - f + i] * (1 - t); }
    }
    return (buffers[kind] = b);
  }
  function loopSrc(kind, out) {
    const c = getCtx(), s = c.createBufferSource(); s.buffer = noise(kind); s.loop = true;
    s.loopStart = 2048 / c.sampleRate; s.connect(out); s.start(c.currentTime, Math.random() * 5); return s;
  }
  const filt = (type, f, q = 0.7) => { const n = getCtx().createBiquadFilter(); n.type = type; n.frequency.value = f; n.Q.value = q; return n; };
  const gain = (v) => { const n = getCtx().createGain(); n.gain.value = v; return n; };
  const chain = (...nodes) => { for (let i = 0; i < nodes.length - 1; i++) nodes[i].connect(nodes[i + 1]); return nodes[0]; };
  const lfo = (target, rate, depth, offset) => {
    const c = getCtx(), o = c.createOscillator(), g = gain(depth); o.frequency.value = rate; o.connect(g); g.connect(target);
    if (offset !== undefined) target.value = offset; o.start(); return o;
  };
  // short burst of filtered noise (droplets, crackles, clinks)
  function burst(out, { at, dur = 0.03, f = 3000, q = 4, type = 'bandpass', vol = 0.2, kind = 'white', pan = 0 }) {
    const c = getCtx(), s = c.createBufferSource(); s.buffer = noise(kind);
    const fl = filt(type, f, q), g = gain(0), p = c.createStereoPanner ? c.createStereoPanner() : null;
    s.connect(fl); fl.connect(g);
    if (p) { p.pan.value = pan; g.connect(p); p.connect(out); } else g.connect(out);
    g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(vol, at + 0.004); g.gain.exponentialRampToValueAtTime(0.0005, at + dur);
    s.start(at, Math.random() * 5); s.stop(at + dur + 0.05);
  }
  function tone(out, { at, f, dur = 0.4, type = 'sine', vol = 0.2, attack = 0.01, f2, pan = 0 }) {
    const c = getCtx(), o = c.createOscillator(), g = gain(0);
    o.type = type; o.frequency.setValueAtTime(f, at); if (f2) o.frequency.exponentialRampToValueAtTime(f2, at + dur * 0.8);
    let node = g;
    if (pan && c.createStereoPanner) { const p = c.createStereoPanner(); p.pan.value = pan; g.connect(p); node = p; }
    o.connect(g); node.connect(out);
    g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(vol, at + attack); g.gain.exponentialRampToValueAtTime(0.0005, at + dur);
    o.start(at); o.stop(at + dur + 0.05);
  }

  // ---------- ambient generators; each returns {stop()} ----------
  const rnd = (a, b) => a + Math.random() * (b - a);
  function every(fn, msMin, msMax) {
    let alive = true, t;
    const loop = () => { if (!alive) return; fn(); t = setTimeout(loop, rnd(msMin, msMax)); };
    t = setTimeout(loop, rnd(0, msMin)); return () => { alive = false; clearTimeout(t); };
  }
  const GEN = {
    white(out) { const s = loopSrc('white', chain(filt('lowpass', 9000), gain(0.5), out)); return () => s.stop(); },
    pink(out) { const s = loopSrc('pink', chain(gain(0.9), out)); return () => s.stop(); },
    brown(out) { const s = loopSrc('brown', chain(gain(0.9), out)); return () => s.stop(); },
    rain(out) {
      const bed = chain(filt('highpass', 500), filt('lowpass', 7000), gain(0.55), out);
      const s = loopSrc('pink', bed);
      const s2 = loopSrc('brown', chain(filt('lowpass', 900), gain(0.25), out));
      const stopDrops = every(() => { const c = getCtx(); for (let i = 0; i < 3; i++) burst(out, { at: c.currentTime + Math.random() * 0.12, dur: rnd(0.01, 0.04), f: rnd(2500, 6500), q: 3, vol: rnd(0.03, 0.09), pan: rnd(-0.8, 0.8) }); }, 40, 140);
      return () => { s.stop(); s2.stop(); stopDrops(); };
    },
    thunder(out) {
      const s = loopSrc('pink', chain(filt('highpass', 400), filt('lowpass', 5000), gain(0.4), out));
      const rumbleBus = chain(filt('lowpass', 160, 0.8), gain(1), out);
      const stop = every(() => {
        const c = getCtx(), src = c.createBufferSource(), g = gain(0), at = c.currentTime + 0.1, len = rnd(3, 6);
        src.buffer = noise('brown'); src.connect(g); g.connect(rumbleBus);
        g.gain.setValueAtTime(0, at); g.gain.linearRampToValueAtTime(rnd(0.6, 1.1), at + rnd(0.1, 0.6));
        g.gain.linearRampToValueAtTime(rnd(0.3, 0.6), at + len * 0.4); g.gain.exponentialRampToValueAtTime(0.001, at + len);
        src.start(at, Math.random() * 4); src.stop(at + len + 0.1);
      }, 9000, 24000);
      return () => { s.stop(); stop(); };
    },
    fireplace(out) {
      const s = loopSrc('brown', chain(filt('lowpass', 700), gain(0.6), out));
      const stop = every(() => { const c = getCtx(); const n = Math.random() < 0.2 ? 4 : 1; for (let i = 0; i < n; i++) burst(out, { at: c.currentTime + i * rnd(0.01, 0.05), dur: rnd(0.005, 0.03), f: rnd(1500, 5000), q: 1, type: 'highpass', vol: rnd(0.08, 0.35), pan: rnd(-0.4, 0.4) }); }, 60, 420);
      return () => { s.stop(); stop(); };
    },
    forest(out) {
      const bp = filt('bandpass', 600, 0.6), g = gain(0.35);
      const s = loopSrc('pink', chain(bp, g, out));
      const o1 = lfo(bp.frequency, 0.07, 250, 650), o2 = lfo(g.gain, 0.11, 0.15, 0.35);
      const stop = every(() => {
        const c = getCtx(), pan = rnd(-0.9, 0.9), base = rnd(2600, 4200), n = Math.floor(rnd(2, 5));
        for (let i = 0; i < n; i++) tone(out, { at: c.currentTime + i * rnd(0.09, 0.16), f: base, f2: base * rnd(1.15, 1.5), dur: rnd(0.06, 0.12), vol: 0.05, pan });
      }, 2500, 8000);
      return () => { s.stop(); o1.stop(); o2.stop(); stop(); };
    },
    ocean(out) {
      const lp = filt('lowpass', 800), g = gain(0.5);
      const s = loopSrc('pink', chain(lp, g, out)), s2 = loopSrc('brown', chain(gain(0.35), g));
      const o1 = lfo(g.gain, 0.09, 0.4, 0.45), o2 = lfo(lp.frequency, 0.09, 500, 900);
      return () => { s.stop(); s2.stop(); o1.stop(); o2.stop(); };
    },
    cafe(out) {
      const voices = [], oscs = [];
      for (let i = 0; i < 4; i++) {
        const bp = filt('bandpass', rnd(350, 1100), 1.8), g = gain(0.12);
        voices.push(loopSrc('pink', chain(bp, g, out)));
        oscs.push(lfo(g.gain, rnd(0.3, 1.2), 0.1, 0.12), lfo(bp.frequency, rnd(0.2, 0.6), 200, rnd(400, 1000)));
      }
      voices.push(loopSrc('brown', chain(filt('lowpass', 300), gain(0.3), out)));
      const stop = every(() => { const c = getCtx(), f = rnd(2200, 4200); tone(out, { at: c.currentTime, f, dur: 0.5, vol: 0.025, pan: rnd(-0.8, 0.8) }); tone(out, { at: c.currentTime + 0.01, f: f * 1.48, dur: 0.35, vol: 0.012 }); }, 3000, 9000);
      return () => { voices.forEach((v) => v.stop()); oscs.forEach((o) => o.stop()); stop(); };
    },
    clock(out) {
      // a soft wooden tick-tock, once a second (some people focus better with it)
      const c = getCtx(); let next = c.currentTime + 0.1, n = 0, alive = true;
      const schedule = () => {
        if (!alive) return;
        while (next < c.currentTime + 1.2) {
          tone(out, { at: next, f: n % 2 ? 1750 : 2100, f2: n % 2 ? 1500 : 1800, dur: 0.035, vol: 0.12, attack: 0.001, type: 'triangle' });
          burst(out, { at: next, dur: 0.012, f: 3500, q: 2, vol: 0.05 });
          next += 1; n++;
        }
      };
      schedule(); const iv = setInterval(schedule, 400);
      return () => { alive = false; clearInterval(iv); };
    },
    lofi(out) {
      // gentle procedural lo-fi: warm electric piano chords, soft bass, dusty drums, vinyl crackle
      const c = getCtx(), bpm = 72, beat = 60 / bpm, bar = beat * 4;
      const warm = chain(filt('lowpass', 1800, 0.5), gain(0.9), out);
      const prog = [[53, 57, 60, 64], [52, 55, 59, 62], [50, 53, 57, 60], [48, 52, 55, 59]]; // Fmaj7 Em7 Dm7 Cmaj7
      const midi = (m) => 440 * Math.pow(2, (m - 69) / 12);
      const crackle = loopSrc('white', chain(filt('highpass', 3000), gain(0.012), out));
      const pops = every(() => burst(out, { at: c.currentTime, dur: 0.01, f: 2500, type: 'highpass', vol: 0.05 }), 300, 1500);
      let next = c.currentTime + 0.1, barN = 0, alive = true;
      const schedule = () => {
        if (!alive) return;
        while (next < c.currentTime + 1.5) {
          const ch = prog[barN % 4];
          ch.forEach((m, i) => { const at = next + i * 0.018 + (barN % 2 ? beat * 2.5 : 0) * 0; tone(warm, { at, f: midi(m + 12), dur: bar * 0.95, vol: 0.035, attack: 0.03, type: 'triangle' }); tone(warm, { at, f: midi(m + 12) * 1.003, dur: bar * 0.8, vol: 0.025, attack: 0.03 }); });
          tone(warm, { at: next + beat * 2.5, f: midi(ch[2] + 24), dur: beat * 1.2, vol: 0.02, type: 'triangle' });
          tone(warm, { at: next, f: midi(ch[0] - 12), dur: beat * 1.8, vol: 0.12 });
          tone(warm, { at: next + beat * 2, f: midi(ch[0] - 12), dur: beat * 1.5, vol: 0.09 });
          for (let b = 0; b < 4; b++) {
            const at = next + b * beat;
            if (b === 0 || b === 2) tone(out, { at, f: 110, f2: 45, dur: 0.35, vol: 0.28 });
            if (b === 1 || b === 3) burst(out, { at, dur: 0.18, f: 1800, q: 0.8, vol: 0.08 });
            burst(out, { at, dur: 0.04, f: 8000, type: 'highpass', vol: 0.025 });
            burst(out, { at: at + beat * 0.58, dur: 0.03, f: 8000, type: 'highpass', vol: 0.018 });
          }
          next += bar; barN++;
        }
      };
      schedule(); const iv = setInterval(schedule, 400);
      return () => { alive = false; clearInterval(iv); crackle.stop(); pops(); };
    },
  };

  const SOUNDS = [
    { id: 'rain', label: 'Rain' }, { id: 'thunder', label: 'Thunderstorm' }, { id: 'fireplace', label: 'Fireplace', icon: 'fire' },
    { id: 'forest', label: 'Forest' }, { id: 'ocean', label: 'Ocean waves' }, { id: 'cafe', label: 'Café' },
    { id: 'white', label: 'White noise' }, { id: 'pink', label: 'Pink noise' }, { id: 'brown', label: 'Brown noise' }, { id: 'lofi', label: 'Lo-fi beats' }, { id: 'clock', label: 'Clock ticking' },
  ];

  const playing = {}; // id -> { stop, gain }
  const Audio = {
    SOUNDS,
    unlock() { getCtx(); },
    isPlaying(id) { return !!playing[id]; },
    anyPlaying() { return Object.keys(playing).length > 0; },
    setMaster(v) { getCtx(); master.gain.setTargetAtTime(v, ctx.currentTime, 0.05); },
    setVolume(id, v) { if (playing[id]) playing[id].gain.gain.setTargetAtTime(v, ctx.currentTime, 0.05); },
    start(id, vol = 0.5) {
      if (playing[id]) return;
      const c = getCtx(), g = gain(0); g.connect(master);
      const stop = GEN[id](g);
      g.gain.setTargetAtTime(vol, c.currentTime, 0.4); // fade in
      playing[id] = { stop, gain: g };
    },
    stop(id) {
      const p = playing[id]; if (!p) return; delete playing[id];
      p.gain.gain.setTargetAtTime(0, ctx.currentTime, 0.25);
      setTimeout(() => { try { p.stop(); } catch (e) {} p.gain.disconnect(); }, 1200);
    },
    stopAll() { Object.keys(playing).forEach((id) => this.stop(id)); },

    // ---------- completion chimes ----------
    CHIMES: { bell: 'Little bell', marimba: 'Marimba', kalimba: 'Kalimba', pop: 'Bubble pop', none: 'Silent' },
    chime(kind, vol = 0.6) {
      if (kind === 'none') return;
      const c = getCtx(), out = gain(vol); out.connect(c.destination); const t = c.currentTime + 0.02;
      if (kind === 'bell') [[880, 0], [1318.5, 0.16], [1760, 0.32]].forEach(([f, d]) => { tone(out, { at: t + d, f, dur: 1.6, vol: 0.18 }); tone(out, { at: t + d, f: f * 2.01, dur: 0.8, vol: 0.05 }); });
      else if (kind === 'marimba') [[523.3, 0], [659.3, 0.13], [784, 0.26], [1046.5, 0.39]].forEach(([f, d]) => { tone(out, { at: t + d, f, dur: 0.5, vol: 0.28, attack: 0.004 }); tone(out, { at: t + d, f: f * 4, dur: 0.08, vol: 0.05, attack: 0.002 }); });
      else if (kind === 'kalimba') [[587.3, 0], [784, 0.2], [880, 0.4], [1174.7, 0.62]].forEach(([f, d]) => { tone(out, { at: t + d, f, dur: 1.1, vol: 0.2, attack: 0.003, type: 'triangle' }); tone(out, { at: t + d, f: f * 3.0, dur: 0.15, vol: 0.04 }); });
      else if (kind === 'pop') [[0, 400], [0.14, 520], [0.28, 700]].forEach(([d, f]) => tone(out, { at: t + d, f, f2: f * 2.2, dur: 0.14, vol: 0.3, attack: 0.003 }));
    },
    // tiny UI blip used for task check-offs
    blip() { try { const c = getCtx(), out = gain(0.25); out.connect(c.destination); tone(out, { at: c.currentTime, f: 660, f2: 1320, dur: 0.12, vol: 0.25, attack: 0.003 }); } catch (e) {} },
  };
  window.MomoAudio = Audio;
})();
