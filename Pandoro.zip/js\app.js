/* App glue: the timer card, tap-the-clock time editing, popup dock, session recording,
   celebrations, toasts, idle fade, ultra focus, noticing when you leave, and sleep mode. */
(function () {
  const St = window.MomoStore, Timer = window.MomoTimer, Panda = window.MomoPanda, Audio = window.MomoAudio;
  const Panels = window.MomoPanels, Rewards = window.MomoRewards, Art = window.MomoArt, I = window.MOMO_ICONS, G = Art.glyph;
  const Coach = window.MomoCoach;
  const $ = (s) => document.querySelector(s);
  const st = () => St.state;
  const MODE_LABEL = { focus: 'Focus', short: 'Short break', long: 'Long break' };
  const gentle = () => document.body.dataset.motion === 'gentle';
  const ultraOn = () => document.body.classList.contains('ultra');

  // ================= little effects =================
  const FX = {
    spawn(x, y, shape, color, { dx, dy, rot, size, dur }) {
      if (gentle() || ultraOn()) return;
      const el = document.createElement('i'); el.className = 'fx-bit';
      el.innerHTML = shape.startsWith('a_') ? `<img src="sprites/${shape}.webp" alt="">` : Art.doodle[shape]; // a_* = drawn art from the sticker sheet
      el.style.cssText = `left:${x}px;top:${y}px;color:${color};width:${size}px;height:${size}px;--dx:${dx}px;--dy:${dy}px;--r:${rot}deg;animation-duration:${dur}ms`;
      $('#fx').appendChild(el); setTimeout(() => el.remove(), dur + 50);
    },
    colors() { const cs = getComputedStyle(document.documentElement); return [cs.getPropertyValue('--accent'), '#ffc94a', '#f37b8b', '#fff4dc', '#8fc6dc']; },
    burst(x, y, n = 18) {
      const c = this.colors();
      for (let i = 0; i < n; i++) { const a = Math.random() * Math.PI * 2, d = 50 + Math.random() * 110; this.spawn(x, y, Art.confetti[i % 4], c[i % c.length], { dx: Math.cos(a) * d, dy: Math.sin(a) * d - 40, rot: (Math.random() - .5) * 360, size: 9 + Math.random() * 10, dur: 1100 + Math.random() * 500 }); }
    },
    hearts(x, y) { for (let i = 0; i < 3; i++) this.spawn(x - 10, y - 10, i === 1 ? 'a_star' : i ? 'a_heart2' : 'a_heart', '', { dx: (Math.random() - .5) * 70, dy: -55 - Math.random() * 50, rot: (Math.random() - .5) * 30, size: 18 + Math.random() * 8, dur: 1200 + i * 160 }); },
  };
  window.MomoFX = FX;

  // ================= toasts (silent during ultra focus) =================
  function toast(text, pose = 'heart', ms = 4200) {
    if (ultraOn()) return;
    const el = document.createElement('div'); el.className = 'toast';
    el.innerHTML = `<img src="${Panda.spriteThumb(pose)}" alt=""><p>${Panels.esc(text)}</p>`;
    $('#toasts').appendChild(el);
    requestAnimationFrame(() => requestAnimationFrame(() => el.classList.add('in')));
    setTimeout(() => { el.classList.remove('in'); el.classList.add('out'); setTimeout(() => el.remove(), 450); }, ms);
  }

  // ================= clock & card =================
  let lastClock = '', lastTitle = '', flashOn = false;
  function fmt(ms) { const s = Math.ceil(ms / 1000), m = Math.floor(s / 60); return `${String(m).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; }
  function renderClock() {
    const t = st().timer, rem = Timer.remaining(), txt = fmt(rem), titleKey = txt + t.status + t.mode + flashOn;
    if (titleKey !== lastTitle) {
      lastTitle = titleKey;
      document.title = flashOn ? `Come back to focus · ${txt}` : t.status === 'idle' && t.mode === 'focus' ? 'Pandoro · study with a red panda' : `${txt} · ${MODE_LABEL[t.mode]}${t.status === 'paused' ? ' (paused)' : ''}`;
    }
    if (txt !== lastClock) {
      $('#clock').innerHTML = txt.split('').map((ch, i) => `<span class="${ch === ':' ? 'colon' : 'dg'}${lastClock && lastClock[i] !== ch && ch !== ':' && !gentle() ? ' tick' : ''}">${ch}</span>`).join('');
      lastClock = txt;
    }
    $('#progressBar').style.transform = `scaleX(${Math.max(0, Math.min(1, 1 - rem / Timer.total())).toFixed(4)})`;
    renderFavicon(); renderPip();
  }

  // ================= tab icon: the panda inside a progress ring =================
  const fav = { img: null, key: '' };
  function renderFavicon() {
    const t = st().timer, p = t.status === 'idle' ? 0 : Math.max(0, Math.min(1, 1 - Timer.remaining() / Timer.total()));
    const key = `${t.status}${t.mode}${Math.round(p * 48)}`;
    if (key === fav.key) return;
    if (!fav.img) { fav.img = new Image(); fav.img.onload = () => { fav.key = ''; renderFavicon(); }; fav.img.src = 'sprites/h_smile.webp'; return; }
    if (!fav.img.complete) return;
    fav.key = key;
    const c = document.createElement('canvas'); c.width = c.height = 64; const x = c.getContext('2d');
    const accent = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#9784cf';
    if (t.status !== 'idle') {
      x.lineWidth = 7; x.lineCap = 'round';
      x.strokeStyle = 'rgba(128,128,140,.35)'; x.beginPath(); x.arc(32, 32, 27, 0, Math.PI * 2); x.stroke();
      x.strokeStyle = t.status === 'paused' ? '#9a95a8' : t.mode === 'focus' ? accent : '#5fb39a';
      x.beginPath(); x.arc(32, 32, 27, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.max(.02, p)); x.stroke();
    }
    const s = t.status === 'idle' ? 60 : 40, h = s * fav.img.naturalHeight / fav.img.naturalWidth;
    x.drawImage(fav.img, 32 - s / 2, 33 - h / 2, s, h);
    // opened straight from a file (file://) the browser won't let a canvas export images: keep the plain icon
    try { $('#favicon').href = c.toDataURL('image/png'); } catch (e) { fav.key = 'off'; renderFavicon = () => {}; }
  }

  // ================= mini timer that stays on top (Document Picture-in-Picture) =================
  let pipWin = null;
  const pipOK = () => 'documentPictureInPicture' in window;
  async function togglePip() {
    if (pipWin) { pipWin.close(); return; }
    if (!pipOK()) { toast("This browser can't pop out a mini timer. Chrome and Edge can.", 'question'); return; }
    try { pipWin = await window.documentPictureInPicture.requestWindow({ width: 280, height: 168 }); }
    catch (e) { pipWin = null; toast("Couldn't pop out the mini timer here. Try it in Chrome or Edge.", 'question'); return; }
    const d = pipWin.document, cs = getComputedStyle(document.documentElement), v = (k) => cs.getPropertyValue(k).trim();
    const font = document.querySelector('link[href*="fonts.googleapis"]');
    if (font) { const l = d.createElement('link'); l.rel = 'stylesheet'; l.href = font.href; d.head.appendChild(l); }
    const st2 = d.createElement('style');
    st2.textContent = `:root{--bg:${v('--bg')};--paper:${v('--paper')};--ink:${v('--ink')};--soft:${v('--soft')};--accent:${v('--accent')};--accent-ink:${v('--accent-ink')}}
      *{box-sizing:border-box;margin:0}body{background:var(--bg);color:var(--ink);font-family:Fredoka,system-ui,sans-serif;height:100vh;display:grid;place-items:center;overflow:hidden;user-select:none}
      .m{display:grid;grid-template-columns:auto 1fr;gap:4px 12px;align-items:center;width:100%;padding:14px 18px}
      img{width:54px;grid-row:span 2}.c{font-size:44px;font-weight:600;letter-spacing:1px;line-height:1;font-variant-numeric:tabular-nums}
      .r{display:flex;align-items:center;justify-content:space-between;gap:8px}.l{font-size:13px;color:var(--soft)}
      button{font:inherit;font-size:13px;font-weight:600;border:0;border-radius:99px;padding:6px 14px;background:var(--accent);color:var(--accent-ink);cursor:pointer}
      .b{grid-column:span 2;height:5px;border-radius:9px;background:color-mix(in srgb,var(--ink) 12%,transparent);overflow:hidden;margin-top:6px}.b i{display:block;height:100%;background:var(--accent);transform-origin:0 50%}`;
    d.head.appendChild(st2);
    d.title = 'Pandoro';
    d.body.innerHTML = `<div class="m"><img id="pi" alt=""><div class="c" id="pc"></div><div class="r"><span class="l" id="pl"></span><button id="pt"></button></div><div class="b"><i id="pb"></i></div></div>`;
    d.getElementById('pi').src = new URL('sprites/h_smile.webp', location.href).href;
    d.getElementById('pt').addEventListener('click', () => { Audio.unlock(); Timer.toggle(); });
    pipWin.addEventListener('pagehide', () => { pipWin = null; });
    pipLast = ''; renderPip();
  }
  let pipLast = '';
  function renderPip() {
    if (!pipWin) return;
    const d = pipWin.document, t = st().timer, rem = Timer.remaining(), key = fmt(rem) + t.status + t.mode;
    if (key === pipLast) return; pipLast = key;
    const g = (id) => d.getElementById(id); if (!g('pc')) return;
    g('pc').textContent = fmt(rem);
    g('pl').textContent = `${MODE_LABEL[t.mode]}${t.intent ? ' · ' + t.intent : ''}`.slice(0, 34);
    g('pt').textContent = t.status === 'running' ? 'Pause' : t.status === 'paused' ? 'Resume' : 'Start';
    g('pb').style.transform = `scaleX(${Math.max(0, Math.min(1, 1 - rem / Timer.total())).toFixed(3)})`;
  }

  // ================= thought pad: park a distraction without leaving the session =================
  let parkFlashT = null;
  function openPark() {
    if (st().sleep) return;
    const f = $('#park'); f.classList.remove('saved'); f.classList.add('open');
    $('#parkInput').value = ''; setTimeout(() => $('#parkInput').focus(), 40);
  }
  function closePark() { $('#park').classList.remove('open', 'saved'); $('#parkInput').blur(); wake(); }
  function onPark(e) {
    e.preventDefault();
    const v = $('#parkInput').value.trim();
    if (!v) return closePark();
    st().tasks.push({ id: St.uid(), title: v, pri: '', est: 1, done: 0, completed: false, createdAt: Date.now(), parked: true });
    st().timer.parked = (st().timer.parked || 0) + 1;
    St.emit('tasks');
    const f = $('#park'); f.classList.add('saved'); $('#parkInput').value = ''; $('#parkInput').placeholder = 'Parked. Back to it.';
    clearTimeout(parkFlashT); parkFlashT = setTimeout(() => { closePark(); $('#parkInput').placeholder = 'Park a thought for later...'; }, 900);
  }

  // ================= keyboard help =================
  function showKeys() {
    let k = $('#keysCard');
    if (k) { k.remove(); return; }
    k = document.createElement('div'); k.id = 'keysCard'; k.className = 'keys-card';
    const rows = [['Space', 'start / pause'], ['R', 'reset'], ['S', 'skip'], ['+', 'add a minute'], ['N', 'park a thought'], ['U', 'ultra focus'], ['F', 'full screen'], ...(pipOK() ? [['P', 'mini timer']] : []), ['M', 'menu'], ['Esc', 'close / exit'], ['?', 'this list']];
    k.innerHTML = `<b>Shortcuts</b>${rows.map(([a, b]) => `<span><kbd>${a}</kbd>${b}</span>`).join('')}`;
    k.addEventListener('click', () => k.remove());
    document.body.appendChild(k);
  }
  function renderControls() {
    const t = st().timer, running = t.status === 'running';
    const label = running ? 'Pause' : t.status === 'paused' ? 'Resume' : t.mode === 'focus' ? 'Start' : 'Start break';
    const b = $('#btnStart');
    if (b.dataset.label !== label) { b.innerHTML = `${running ? G.pause : G.play}<span>${label}</span>`; b.dataset.label = label; }
    b.setAttribute('aria-label', label);
    document.body.dataset.mode = t.mode; document.body.dataset.status = t.status;
    $('#modeChip span').textContent = MODE_LABEL[t.mode];
    document.querySelectorAll('#modeMenu button').forEach((m) => m.classList.toggle('on', m.dataset.mode === t.mode));
    const n = st().settings.interval, c = (t.cycle || 0) % n || (t.mode === 'long' ? n : 0);
    $('#cycle').innerHTML = Array.from({ length: n }, (_, i) => `<i class="${i < c ? 'on' : ''}"></i>`).join('');
    $('#cycle').title = `${c} of ${n} focus sessions before a long break`;
    const m = window.MomoStats.metrics();
    $('#todayPill').innerHTML = `<img src="${I.tomato}" alt=""><b>${m.todaySessions}</b><span>today</span>${m.streak > 1 ? `<i></i><b>${m.streak}</b><span>day streak</span>` : ''}`;
    if (ultraOn()) $('#ultraLabel').textContent = t.intent ? `Ultra focus · ${t.intent}` : 'Ultra focus';
  }
  function renderNames() { $('#sleepName').textContent = st().settings.name; }

  // ================= tap the clock: add or take off time =================
  let editAsk = 0;
  function renderTimeEdit() {
    const box = $('#timeEdit'), t = st().timer, extra = Math.round((t.extra || 0) / 60000);
    if (editAsk) {
      box.innerHTML = `<p>Take ${Math.abs(editAsk)} minute${editAsk === -1 ? '' : 's'} off this session?</p>
        <div class="te-row"><button class="pill-btn ghost sm" data-te="no">Keep it</button><button class="pill-btn sm" data-te="yes">Take it off</button></div>`;
      return;
    }
    box.innerHTML = `<div class="te-row">${[-5, -1, 1, 5].map((d) => `<button class="te-btn${d < 0 ? ' minus' : ''}" data-te="${d}" aria-label="${d > 0 ? 'Add' : 'Take off'} ${Math.abs(d)} minute${Math.abs(d) === 1 ? '' : 's'}">${d > 0 ? '+' : '−'}${Math.abs(d)}</button>`).join('')}</div>
      <p class="te-note">${extra ? `${extra > 0 ? '+' : '−'}${Math.abs(extra)} min this session · ` : ''}just this session</p>`;
  }
  function toggleTimeEdit(open) {
    const box = $('#timeEdit');
    if (open === undefined) open = !box.classList.contains('open');
    if (ultraOn()) open = false;
    editAsk = 0;
    if (open) { renderTimeEdit(); toggleModeMenu(false); }
    box.classList.toggle('open', open); $('#clock').setAttribute('aria-expanded', open);
  }
  function onTimeEdit(e) {
    const b = e.target.closest('[data-te]'); if (!b) return;
    e.stopPropagation();
    const v = b.dataset.te;
    if (v === 'no') { editAsk = 0; return renderTimeEdit(); }
    if (v === 'yes') { const d = Timer.adjust(editAsk * 60000); editAsk = 0; renderTimeEdit(); if (d) bump('minus'); return; }
    const d = +v;
    if (d < 0) { editAsk = d; return renderTimeEdit(); } // taking time off always asks first
    if (Timer.adjust(d * 60000)) { bump('plus'); renderTimeEdit(); }
  }
  function bump(kind) { const c = $('#clock'); c.classList.remove('bump-plus', 'bump-minus'); void c.offsetWidth; c.classList.add('bump-' + kind); }

  // ================= mode menu =================
  function toggleModeMenu(open) {
    const chip = $('#modeChip'), menu = $('#modeMenu');
    if (open === undefined) open = !menu.classList.contains('open');
    if (open) toggleTimeEdit(false);
    menu.classList.toggle('open', open); chip.setAttribute('aria-expanded', open);
  }

  // ================= "are you sure?" without dialogs =================
  let armed = null, armT = null;
  const SURE = { reset: 'resetSure', skip: 'skipSure' };
  function confirmTap(kind, el, fn) {
    const t = st().timer, spent = t.status === 'idle' ? 0 : Timer.total() - Timer.remaining();
    if (spent < 60000 || armed === kind) { disarm(); return fn(); }
    disarm(); armed = kind; el && el.classList.add('armed');
    const key = SURE[kind] || 'switchBack';
    if (st().avatar.place === 'off' || !st().settings.messages) toast(Panda.MSG[key][0], 'thinking', 2600); else Panda.say(key, 3200);
    armT = setTimeout(disarm, 3500);
  }
  function disarm() { armed = null; clearTimeout(armT); document.querySelectorAll('.armed').forEach((e) => e.classList.remove('armed')); }

  // ================= popup dock =================
  let dockHover = null;
  function openDock() { document.body.classList.add('dock-open'); $('#dockHandle').setAttribute('aria-expanded', 'true'); }
  function closeDock() { document.body.classList.remove('dock-open'); $('#dockHandle').setAttribute('aria-expanded', 'false'); }
  function toggleDock() { document.body.classList.contains('dock-open') ? closeDock() : openDock(); }

  // ================= ultra focus =================
  // only the clock, no messages, and the tab title calls you back if you wander off
  let usedFullscreen = false;
  function setUltra(on) {
    if (on === ultraOn()) return;
    document.body.classList.toggle('ultra', on);
    if (on) {
      Panels.close(); closeDock(); toggleModeMenu(false); toggleTimeEdit(false); disarm();
      const t = st().timer;
      if (t.mode !== 'focus') Timer.setMode('focus');
      if (st().timer.status !== 'running') { Audio.unlock(); resumeAmbient(); Timer.start(); }
      const el = document.documentElement;
      if (el.requestFullscreen && !document.fullscreenElement) el.requestFullscreen().then(() => { usedFullscreen = true; }).catch(() => {});
      renderControls();
    } else {
      stopFlash();
      if (usedFullscreen && document.fullscreenElement) document.exitFullscreen().catch(() => {});
      usedFullscreen = false;
    }
    wake();
  }
  document.addEventListener('fullscreenchange', () => { if (!document.fullscreenElement && usedFullscreen) { usedFullscreen = false; setUltra(false); } });
  // plain full screen (bottom-right button or F), separate from ultra focus
  function toggleFullscreen() {
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    else if (document.documentElement.requestFullscreen) document.documentElement.requestFullscreen().catch(() => {});
  }
  function renderFullBtn() {
    const on = !!document.fullscreenElement, b = $('#btnFull');
    b.innerHTML = on ? G.shrink : G.expand;
    b.setAttribute('aria-label', on ? 'Exit full screen' : 'Full screen');
    b.title = on ? 'Exit full screen (F)' : 'Full screen (F)';
  }
  let flashT = null;
  function startFlash() { stopFlash(); flashT = setInterval(() => { flashOn = !flashOn; renderClock(); }, 1200); }
  function stopFlash() { clearInterval(flashT); flashT = null; flashOn = false; renderClock(); }

  // ================= progress hooks =================
  function announceAchievements(list, delay) {
    list.forEach((a, i) => setTimeout(() => { toast(`Achievement: ${a.title}! Unlocked ${a.rewards.map(Rewards.rewardLabel).join(', ')}.`, a.pose, 6000); celebrate(); }, delay + i * 1600));
  }
  function afterProgress() {
    announceAchievements(Rewards.check(), 600);
    const goals = Rewards.checkGoals();
    goals.forEach((g, i) => setTimeout(() => { toast(`Goal reached: ${g.label.toLowerCase()}!`, 'heart'); Panda.react('heart', 'goal', 3500, true); }, 300 + i * 1400));
    if (goals.length) announceAchievements(Rewards.check(), 2200);
    renderControls();
    if (Panels.current) Panels.refresh();
  }
  function celebrate() {
    const host = st().avatar.place === 'side' ? $('#sidePanda') : st().avatar.place === 'off' ? $('#clock') : $('#panda');
    const r = host.getBoundingClientRect();
    FX.burst(r.left + r.width / 2, r.top + r.height * .4, 20);
  }
  function notify(title, body) {
    if (!st().settings.notify || st().sleep || !('Notification' in window) || Notification.permission !== 'granted') return;
    try { const n = new Notification(title, { body, icon: I.tomato, silent: true }); setTimeout(() => n.close(), 8000); } catch (e) {}
  }

  const hooks = {
    onTick() { renderClock(); },
    onStart(mode) { renderControls(); Panda.say(mode === 'focus' ? 'start' : mode); },
    onPause() { renderControls(); Panda.say('pause'); },
    onReset() { renderControls(); Panda.react('overwhelm', 'reset', 2400); },
    onRecord(rec) {
      const S = st(), t = S.timer, id = St.uid();
      S.history.push({ id, ...rec, intent: (t.intent || '').trim() || undefined, slips: t.slips || 0 });
      if (rec.completed && rec.taskId) { const tk = S.tasks.find((x) => x.id === rec.taskId); if (tk) tk.done = (tk.done || 0) + 1; }
      if (rec.completed) S.checkin = { recId: id, intent: (t.intent || '').trim(), slips: t.slips || 0 };
      St.save();
    },
    onComplete(mode, silent) {
      if (silent) return;
      if (mode === 'focus' && ultraOn()) setUltra(false); // the session is done: come back out
      if (!st().sleep) Audio.chime(st().settings.chime, st().settings.chimeVol);
      if (st().settings.stopAmbientOnEnd) { Audio.stopAll(); st().ambient.on = []; }
      $('#timerCard').classList.remove('done-glow'); void $('#timerCard').offsetWidth; $('#timerCard').classList.add('done-glow');
      if (mode === 'focus') {
        Panda.react('cheer', 'done', 4000, true); celebrate();
        const parked = st().timer.parked || 0;
        if (parked) setTimeout(() => Panda.say(`You parked ${parked === 1 ? 'a thought' : parked + ' thoughts'}. ${parked === 1 ? "It's" : "They're"} waiting in your tasks.`, 5200), 4600);
        notify('Focus session done!', `Nice work. Time for a ${st().timer.cycle % st().settings.interval === 0 ? 'long' : 'short'} break.`);
      } else { Panda.react('idea', 'breakOver', 3200, true); notify('Break finished', 'Ready for another focus session?'); }
    },
    onAdvance(from, next, natural, silent) {
      toggleTimeEdit(false);
      renderControls(); renderClock(); Coach.render();
      if (from === 'focus') { afterProgress(); if (ultraOn()) setUltra(false); }
      if (silent && natural) { st().checkin = null; toast(`While you were away, ${from === 'focus' ? 'a focus session finished' : 'your break finished'}. It's saved!`, 'peek'); }
    },
  };

  // ================= noticing when you leave =================
  let awayAt = 0;
  document.addEventListener('visibilitychange', () => {
    const t = st().timer, focusing = t.status === 'running' && t.mode === 'focus';
    if (document.hidden) { if (focusing) { awayAt = Date.now(); if (ultraOn()) startFlash(); } Panda.refresh(); return; }
    stopFlash();
    const ms = awayAt ? Date.now() - awayAt : 0; awayAt = 0;
    if (focusing && ms > 15000) {
      t.slips = (t.slips || 0) + 1; t.awayMs = (t.awayMs || 0) + ms; St.save();
      const m = Math.round(ms / 60000), gone = m < 1 ? 'less than a minute' : m === 1 ? 'a minute' : `${m} minutes`;
      setTimeout(() => Panda.react('wave', `${Panda.MSG.back[Math.floor(Math.random() * 3)]} You were gone ${gone}.`, 4200, true), 400);
    } else Panda.refresh();
  });

  // ================= idle fade =================
  let idleT = null;
  function wake() {
    document.body.classList.remove('idle');
    clearTimeout(idleT);
    const s = st().settings;
    if (s.idleMode === 'off' && !ultraOn()) return;
    const delay = ultraOn() ? 2.5 : st().timer.status === 'running' ? s.idleDelay : Math.max(40, s.idleDelay * 5);
    idleT = setTimeout(() => {
      const a = document.activeElement;
      if (!ultraOn() && (Panels.current || st().sleep || st().checkin || $('#timeEdit').classList.contains('open') || (a && ['INPUT', 'SELECT', 'TEXTAREA'].includes(a.tagName)))) return wake();
      closeDock(); toggleModeMenu(false);
      document.body.classList.add('idle');
      document.body.dataset.idle = s.idleMode;
    }, delay * 1000);
  }

  // ================= sleep mode =================
  function setSleep(on) {
    if (on) setUltra(false);
    st().sleep = on; St.emit('sleep');
    document.body.classList.toggle('sleeping', on);
    if (on) { Panels.close(); closeDock(); if (st().timer.status === 'running') Timer.pause(); Panda.say('sleep', 3000); }
    else { Panda.react('cheer', 'wake', 3000, true); wake(); }
    Panda.refresh();
  }

  // ================= init =================
  function init() {
    const S = st();
    if (S.look.mode === 'kraft') S.look.mode = 'dark'; // older saves
    document.body.dataset.motion = matchMedia('(prefers-reduced-motion: reduce)').matches && S.settings.motion === 'full' ? 'gentle' : S.settings.motion;
    $('#brandIcon').src = 'sprites/h_smile.webp';
    $('#btnReset').innerHTML = G.reset; $('#btnSkip').innerHTML = G.skip; $('#btnSettings').innerHTML = G.gear; $('#btnUltra').innerHTML = G.target;
    $('#dockHandle').innerHTML = G.up;
    Panels.init();
    Panda.init();
    Coach.init();
    renderNames();

    $('#btnStart').addEventListener('click', () => { disarm(); Audio.unlock(); resumeAmbient(); Timer.toggle(); });
    $('#btnReset').addEventListener('click', (e) => confirmTap('reset', e.currentTarget, () => Timer.reset()));
    $('#btnSkip').addEventListener('click', (e) => confirmTap('skip', e.currentTarget, () => Timer.skip()));
    $('#btnSettings').addEventListener('click', () => (Panels.current === 'settings' ? Panels.close() : Panels.open('settings')));
    $('#btnUltra').addEventListener('click', () => setUltra(!ultraOn()));
    $('#ultraExit').addEventListener('click', () => setUltra(false));
    $('#btnFull').addEventListener('click', toggleFullscreen);
    if (pipOK()) { $('#btnPip').hidden = false; $('#btnPip').innerHTML = G.popout; $('#btnPip').addEventListener('click', togglePip); }
    $('#parkIco').innerHTML = G.note;
    $('#park').addEventListener('submit', onPark);
    $('#parkInput').addEventListener('blur', () => setTimeout(() => { if (!$('#parkInput').value.trim() && !$('#park').classList.contains('saved')) closePark(); }, 150));
    document.addEventListener('fullscreenchange', renderFullBtn);
    renderFullBtn();
    $('#modeChip').addEventListener('click', (e) => { e.stopPropagation(); toggleModeMenu(); });
    $('#modeMenu').addEventListener('click', (e) => {
      const b = e.target.closest('[data-mode]'); if (!b) return;
      const m = b.dataset.mode, t = st().timer;
      if (m === t.mode && t.status === 'idle') return toggleModeMenu(false);
      confirmTap('mode:' + m, b, () => { Timer.setMode(m); toggleModeMenu(false); });
    });
    $('#clock').addEventListener('click', (e) => { e.stopPropagation(); toggleTimeEdit(); });
    $('#timeEdit').addEventListener('click', onTimeEdit);
    $('#wakeBtn').addEventListener('click', () => setSleep(false));

    $('#dockHandle').addEventListener('click', (e) => { e.stopPropagation(); toggleDock(); });
    $('#dockHandle').addEventListener('mouseenter', () => { dockHover = setTimeout(openDock, 260); });
    $('#dockHandle').addEventListener('mouseleave', () => clearTimeout(dockHover));
    $('#dockZone').addEventListener('mouseleave', () => { if (matchMedia('(hover: hover)').matches) setTimeout(() => { if (!$('#dockZone').matches(':hover')) closeDock(); }, 500); });
    document.addEventListener('click', (e) => {
      if (!e.target.closest('#dockZone')) closeDock();
      if (!e.target.closest('.mode-wrap')) toggleModeMenu(false);
      if (!e.target.closest('.clock-wrap')) toggleTimeEdit(false);
    });

    ['mousemove', 'mousedown', 'keydown', 'touchstart', 'wheel'].forEach((ev) => window.addEventListener(ev, wake, { passive: true }));
    document.addEventListener('keydown', (e) => {
      const tag = (e.target.tagName || '').toLowerCase();
      if (e.key === 'Escape') {
        if ($('#park').classList.contains('open')) return closePark();
        if ($('#keysCard')) return $('#keysCard').remove();
        if (st().sleep) setSleep(false);
        else if (ultraOn()) setUltra(false);
        else { Panels.close(); closeDock(); toggleModeMenu(false); toggleTimeEdit(false); disarm(); }
        return;
      }
      if (tag === 'input' || tag === 'textarea' || tag === 'select' || e.metaKey || e.ctrlKey || e.altKey) return;
      if (e.code === 'Space' && tag !== 'button') { e.preventDefault(); disarm(); Audio.unlock(); resumeAmbient(); Timer.toggle(); }
      else if (e.key === 'n' || e.key === 'N') { e.preventDefault(); openPark(); } // works in ultra focus too
      else if (ultraOn()) return; // in ultra focus only Space, N and Esc do anything
      else if (e.key === '?') showKeys();
      else if ((e.key === 'p' || e.key === 'P') && pipOK()) togglePip();
      else if (e.key === 'r' || e.key === 'R') confirmTap('reset', $('#btnReset'), () => Timer.reset());
      else if (e.key === 's' || e.key === 'S') confirmTap('skip', $('#btnSkip'), () => Timer.skip());
      else if (e.key === 'm' || e.key === 'M') toggleDock();
      else if (e.key === 'u' || e.key === 'U') setUltra(true);
      else if (e.key === 'f' || e.key === 'F') toggleFullscreen();
      else if (e.key === '+' || e.key === '=') { if (Timer.adjust(60000)) bump('plus'); }
    });

    Timer.init(hooks);
    St.on((topic) => { renderControls(); if (topic === 'timer') { renderClock(); if ($('#timeEdit').classList.contains('open') && !editAsk) renderTimeEdit(); } if (topic === 'settings') wake(); });
    if (S.sleep) document.body.classList.add('sleeping');
    renderControls(); renderClock(); Coach.render(true); wake();
    requestAnimationFrame(() => document.body.classList.add('ready'));

    const today = St.dayKey();
    if (!S.meta.lastDay) setTimeout(() => { Panda.react('wave', null, 5200, true); Panda.say('firstVisit', 5200); }, 700);
    else if (!S.sleep && S.timer.status !== 'running') setTimeout(() => Panda.react(S.meta.lastDay === today ? 'wave' : 'walk', 'welcome', 3400, true), 600);
    S.meta.lastDay = today; St.save();
  }
  let resumed = false;
  function resumeAmbient() {
    if (resumed) return; resumed = true;
    const amb = st().ambient;
    if (amb.on.length) { Audio.setMaster(amb.master); amb.on.forEach((id) => Audio.start(id, amb.vol[id] ?? 0.5)); Panda.refresh(); }
  }
  window.addEventListener('pointerdown', () => { Audio.unlock(); resumeAmbient(); }, { once: true });

  // installable + works offline (only when served over http/https)
  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));

  window.MomoApp = { toast, afterProgress, setSleep, setUltra, renderNames, celebrate, closeDock, openDock, openPark, showKeys, togglePip };
  init();
})();
