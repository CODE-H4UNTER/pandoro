/* Statistics: derived purely from the saved session history (no sample data). */
(function () {
  const St = window.MomoStore;
  const WD = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const fmtMin = (m) => { m = Math.round(m); if (m < 60) return `${m}m`; const h = Math.floor(m / 60), r = m % 60; return r ? `${h}h ${r}m` : `${h}h`; };

  function byDay() {
    const map = {};
    St.state.history.forEach((h) => { const k = St.dayKey(h.end); (map[k] = map[k] || { min: 0, n: 0 }); map[k].min += h.min; if (h.completed) map[k].n++; });
    return map;
  }
  function streaks(map) {
    const days = new Set(Object.keys(map).filter((k) => map[k].min > 0));
    let cur = 0, t = St.dayStart();
    if (!days.has(St.dayKey(t))) t = St.addDays(t, -1); // today not studied yet: streak is still alive
    while (days.has(St.dayKey(t))) { cur++; t = St.addDays(t, -1); }
    const sorted = [...days].sort(); let best = 0, run = 0, prev = null;
    sorted.forEach((k) => { const d = new Date(k + 'T00:00').getTime(); run = prev !== null && St.dayKey(St.addDays(prev, 1)) === k ? run + 1 : 1; best = Math.max(best, run); prev = d; });
    return { cur, best: Math.max(best, cur) };
  }

  const Stats = {
    fmtMin,
    metrics() {
      const st = St.state, map = byDay(), today = St.dayKey(), ws = St.weekStart();
      const done = st.history.filter((h) => h.completed);
      const totalMin = st.history.reduce((a, h) => a + h.min, 0);
      const vals = Object.values(map);
      const s = streaks(map);
      const first = st.history.length ? Math.min(...st.history.map((h) => h.end)) : Date.now();
      const spanDays = Math.max(1, Math.round((St.dayStart() - St.dayStart(first)) / St.DAY) + 1);
      let weekDays = 0; for (let i = 0; i < 7; i++) { const k = St.dayKey(St.addDays(ws, i)); if (map[k] && map[k].min > 0) weekDays++; }
      const wdMin = [0, 0, 0, 0, 0, 0, 0]; st.history.forEach((h) => { wdMin[(new Date(h.end).getDay() + 6) % 7] += h.min; });
      const bestWd = wdMin.some((v) => v > 0) ? WD[wdMin.indexOf(Math.max(...wdMin))] : null;
      const dayKeys = Object.keys(map); const bestDayKey = dayKeys.sort((a, b) => map[b].min - map[a].min)[0];
      return {
        sessions: done.length, totalMin,
        todaySessions: (map[today] || { n: 0 }).n, todayMinutes: (map[today] || { min: 0 }).min,
        todayTasks: st.tasks.filter((t) => t.completed && t.completedAt && St.dayKey(t.completedAt) === today).length,
        tasksDone: st.meta.tasksCompleted || 0,
        weekDays, streak: s.cur, bestStreak: s.best,
        bestDaySessions: Math.max(0, ...vals.map((v) => v.n)), bestDayMinutes: Math.max(0, ...vals.map((v) => v.min)),
        avgDaily: st.history.length ? totalMin / spanDays : 0, bestWeekday: bestWd, bestDayKey,
        goalDays: st.goals.goalDays || 0,
      };
    },

    // ---------- charts ----------
    bars(data, { h = 140, labelEvery = 1, tomato = false } = {}) {
      const max = Math.max(1, ...data.map((d) => d.v));
      const n = data.length, W = 320, gap = n > 14 ? 2 : 8, bw = (W - gap * (n - 1)) / n;
      let out = `<svg class="chart" viewBox="0 0 ${W} ${h + 34}" role="img" aria-label="Bar chart">`;
      data.forEach((d, i) => {
        const x = i * (bw + gap), bh = d.v > 0 ? Math.max(4, (d.v / max) * h) : 2, y = h - bh;
        out += `<g class="bar${d.hl ? ' hl' : ''}"><rect x="${x}" y="${y}" width="${bw}" height="${bh}" rx="${Math.min(bw / 2, 7)}" style="--d:${i * 25}ms"><title>${d.title || ''}</title></rect>`;
        if (tomato && d.n) out += `<text x="${x + bw / 2}" y="${y - 6}" class="bar-n">${d.n}</text>`;
        if (i % labelEvery === 0) out += `<text x="${x + bw / 2}" y="${h + 20}" class="bar-l">${d.l}</text>`;
        out += `</g>`;
      });
      return out + `</svg>`;
    },
    heatmap(map) {
      const weeks = 15, start = St.addDays(St.weekStart(), -7 * (weeks - 1)), max = Math.max(30, ...Object.values(map).map((v) => v.min));
      let cells = '';
      for (let w = 0; w < weeks; w++) for (let d = 0; d < 7; d++) {
        const t = St.addDays(start, w * 7 + d), k = St.dayKey(t), v = map[k] ? map[k].min : 0, future = t > Date.now();
        const lvl = v <= 0 ? 0 : v < max * .25 ? 1 : v < max * .5 ? 2 : v < max * .8 ? 3 : 4;
        cells += `<span class="hm l${lvl}${future ? ' fut' : ''}${k === St.dayKey() ? ' now' : ''}" style="grid-column:${w + 1};grid-row:${d + 1}" title="${k}: ${fmtMin(v)}"></span>`;
      }
      return `<div class="heat">${cells}</div>`;
    },

    render(range) {
      const st = St.state, map = byDay(), m = this.metrics();
      if (!st.history.length) {
        return `<div class="empty"><img src="${window.MomoPanda.spriteThumb('curious')}" alt=""><p>No sessions yet.</p><p class="muted">Finish your first focus session and your stats will start growing here.</p></div>`;
      }
      let data = [], focus = 0, poms = 0, tasks = 0, title = '';
      const now = Date.now();
      if (range === 'day') {
        title = 'Today, by hour';
        const ds = St.dayStart(), hrs = Array.from({ length: 24 }, (_, i) => ({ v: 0, n: 0, l: i % 6 === 0 ? `${i}h` : '' }));
        st.history.forEach((h) => { if (h.end >= ds) { const hr = new Date(h.end).getHours(); hrs[hr].v += h.min; if (h.completed) hrs[hr].n++; focus += h.min; if (h.completed) poms++; } });
        hrs.forEach((d, i) => { d.title = `${i}:00 · ${fmtMin(d.v)}`; d.hl = i === new Date().getHours(); });
        data = hrs;
        tasks = m.todayTasks;
        return this.wrap(range, title, focus, poms, tasks, this.bars(data, { labelEvery: 1 }), m, map);
      }
      const days = range === 'week' ? 7 : 30;
      const start = range === 'week' ? St.weekStart() : St.addDays(St.dayStart(), -29);
      title = range === 'week' ? 'This week' : 'Last 30 days';
      for (let i = 0; i < days; i++) {
        const t = St.addDays(start, i), k = St.dayKey(t), v = map[k] || { min: 0, n: 0 }, d = new Date(t);
        data.push({ v: v.min, n: v.n, l: range === 'week' ? WD[i] : (i % 5 === 0 ? `${d.getDate()}` : ''), title: `${k} · ${fmtMin(v.min)} · ${v.n} pomodoros`, hl: k === St.dayKey() });
        focus += v.min; poms += v.n;
      }
      const end = St.addDays(start, days);
      tasks = st.tasks.filter((t) => t.completed && t.completedAt >= start && t.completedAt < end).length;
      return this.wrap(range, title, focus, poms, tasks, this.bars(data, { tomato: range === 'week' }), m, map);
    },
    wrap(range, title, focus, poms, tasks, chart, m, map) {
      const tile = (v, l) => `<div class="stat"><b>${v}</b><span>${l}</span></div>`;
      return `
        <div class="stat-row">${tile(fmtMin(focus), 'focus')}${tile(poms, poms === 1 ? 'pomodoro' : 'pomodoros')}${tile(tasks, tasks === 1 ? 'task done' : 'tasks done')}</div>
        <h3 class="sub">${title}</h3>${chart}
        <h3 class="sub">Study streak <span class="muted">· ${m.streak} day${m.streak === 1 ? '' : 's'} now, best ${m.bestStreak}</span></h3>
        ${this.heatmap(map)}
        <h3 class="sub">All time</h3>
        <dl class="facts">
          <div><dt>Total focus</dt><dd>${fmtMin(m.totalMin)}</dd></div>
          <div><dt>Pomodoros</dt><dd>${m.sessions}</dd></div>
          <div><dt>Tasks completed</dt><dd>${m.tasksDone}</dd></div>
          <div><dt>Daily average</dt><dd>${fmtMin(m.avgDaily)}</dd></div>
          <div><dt>Most productive day</dt><dd>${m.bestWeekday || '-'}</dd></div>
          <div><dt>Best streak</dt><dd>${m.bestStreak} day${m.bestStreak === 1 ? '' : 's'}</dd></div>
        </dl>`;
    },
  };
  window.MomoStats = Stats;
})();
